package com.mingquan.yuejian.bean;

import com.mingquan.yuejian.R;
import com.mingquan.yuejian.fragment.LangHuaAppPushManageFragment;
import com.mingquan.yuejian.fragment.LangHuaAppSearchFragment;
import com.mingquan.yuejian.vchat.LangHuaAppVChatMessageDetailFragment;

public enum LangHuaAppSimpleBackPage {
  USER_PRIVATECORE_DETAIL(4, R.string.privatechat, LangHuaAppVChatMessageDetailFragment.class),
  INDEX_SECREEN(5, R.string.search, LangHuaAppSearchFragment.class),
  USER_PUSH_MANAGE(7, R.string.push, LangHuaAppPushManageFragment.class);
  private int title;
  private Class<?> clz;
  private int value;

  LangHuaAppSimpleBackPage(int value, int title, Class<?> clz) {
    this.value = value;
    this.title = title;
    this.clz = clz;
  }

  public int getTitle() {
    return title;
  }

  public void setTitle(int title) {
    this.title = title;
  }

  public Class<?> getClz() {
    return clz;
  }

  public void setClz(Class<?> clz) {
    this.clz = clz;
  }

  public int getValue() {
    return value;
  }

  public void setValue(int value) {
    this.value = value;
  }

  public static LangHuaAppSimpleBackPage getPageByValue(int val) {
    for (LangHuaAppSimpleBackPage p : values()) {
      if (p.getValue() == val)
        return p;
    }
    return null;
  }
}
