package com.mingquan.yuejian.huawei.push.handler;

import com.mingquan.yuejian.huawei.common.LangHuaAppICallbackCode;

/**
 * 获取 pushtoken 回调
 */
public interface LangHuaAppGetTokenHandler extends LangHuaAppICallbackCode {
}
