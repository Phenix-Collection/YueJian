package com.mingquan.yuejian.hyphenate;

public interface ConversationView {

    void onAllConversationsLoaded(boolean isEmpty);
}
