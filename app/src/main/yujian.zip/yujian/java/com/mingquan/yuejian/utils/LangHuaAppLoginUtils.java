package com.mingquan.yuejian.utils;

import android.app.Activity;
import android.content.Context;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.LangHuaAppAppManager;
import com.hyphenate.EMCallBack;
import com.hyphenate.chat.EMClient;

import cn.jpush.android.api.JPushInterface;

public class LangHuaAppLoginUtils {
    private static LangHuaAppLoginUtils loginUtils = null;

    public static LangHuaAppLoginUtils getInstance() {
        if (null == loginUtils) {
            loginUtils = new LangHuaAppLoginUtils();
        }
        return loginUtils;
    }

    public static void outLogin(final Context context) {
        JPushInterface.stopPush(context);
        LangHuaAppAppContext.getInstance().Logout();
        LangHuaAppAppManager.getAppManager().finishAllActivity();
        EMClient.getInstance().logout(true, new EMCallBack() {
            @Override
            public void onSuccess() {
                LangHuaAppAppContext.getInstance().mChatServer.close();
                LangHuaAppAppContext.getInstance().mChatServer = null;
                LangHuaAppUIHelper.showLoginSelectActivity(context);
                ((Activity)context).finish();
            }

            @Override
            public void onError(int i, String s) {
                LangHuaAppTLog.error("环信退出失败");
            }

            @Override
            public void onProgress(int i, String s) {
            }
        });
    }
}
