package com.mingquan.yuejian.ui.view;



import android.content.Context;
import android.util.AttributeSet;
import android.widget.VideoView;

/**
 * 全屏VideoView
 */
public class LangHuaAppFullScreenVideoView extends VideoView {


    public LangHuaAppFullScreenVideoView(Context context) {
        super(context);
// TODO Auto-generated constructor stub
    }
    public LangHuaAppFullScreenVideoView(Context context, AttributeSet attrs)
    {
        super(context,attrs);
    }
    public LangHuaAppFullScreenVideoView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context,attrs,defStyle);
    }
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        int width = getDefaultSize(0, widthMeasureSpec);
        int height = getDefaultSize(0, heightMeasureSpec);
        setMeasuredDimension(width , height);
    }


}
