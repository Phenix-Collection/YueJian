package com.mingquan.yuejian.interf;

import android.view.View;

/**
 * 基类fragment实现接口
 *
 */
public interface LangHuaAppIBaseFragment {
  void initView(View view);

  void initData();
}
