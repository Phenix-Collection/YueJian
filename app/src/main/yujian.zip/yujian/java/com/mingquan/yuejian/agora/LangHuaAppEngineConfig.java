package com.mingquan.yuejian.agora;

public class LangHuaAppEngineConfig {
    public int mClientRole;

    public int mVideoProfile;

    public int mUid;

    public String mChannel;

    public void reset() {
        mChannel = null;
    }

    LangHuaAppEngineConfig() {
    }
}
