package com.mingquan.yuejian.utils.network;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * 网络状态相关
 */

public class LangHuaAppNetStatusBroadcast extends BroadcastReceiver {
    private static final String TAG = "LangHuaAppNetStatusBroadcast";
    public static final String NET_CHANGE_ACTION = "android.net.conn.CONNECTIVITY_CHANGE";
    /**
     * 有些时候网络改变时会调用两次,使用这个变了记录上一次改变时的网络状态,如果和上一次相同,则不向下通知
     */
    private static LangHuaAppNetType sNetTypeCache = null;

    @Override
    public void onReceive(Context context, Intent intent) {
        LangHuaAppNetTools.init(context);
        Log.i(TAG, "Cache Net :" + sNetTypeCache);
        if (LangHuaAppNetTools.netType() == sNetTypeCache) {
            return;
        }
        Log.i(TAG, "Changed net :" + LangHuaAppNetTools.netType());
        if (intent.getAction().equals(NET_CHANGE_ACTION)) {
            sNetTypeCache = LangHuaAppNetTools.netType();
            if (sNetTypeCache.equals(LangHuaAppNetType.NO_NET)) {
                return;
            }
            /*if (AppContext.getInstance().mChatServerUrl == null && !AppContext.getInstance().mChatServer.mSocket.connected()) {
                AppContext.getInstance().getConfig();
            }*/
        }
    }
}
