package com.mingquan.yuejian.vchat;

import com.mingquan.yuejian.fragment.LangHuaAppBaseDialogFragment;

/**
 * Created by Administrator on 2018/8/30
 *
 * 编辑认证资料
 */

public class LangHuaAppVChatEditFragment extends LangHuaAppBaseDialogFragment {

}
