package com.mingquan.yuejian.interf;

import com.mingquan.yuejian.bean.LangHuaAppChatBean;
import com.mingquan.yuejian.bean.LangHuaAppSendGiftBean;

/**
 * Created by Administrator on 2016/3/17.
 */
public interface LangHuaAppIChatServer {
  void onConnect(boolean res);

  void onShowSendGift(LangHuaAppSendGiftBean contentJson, LangHuaAppChatBean chatBean, int index, String broadCastVotes);

  void onError();
}
