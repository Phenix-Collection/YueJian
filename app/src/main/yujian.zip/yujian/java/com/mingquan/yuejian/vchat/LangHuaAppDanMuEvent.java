package com.mingquan.yuejian.vchat;

import com.mingquan.yuejian.proto.model.LangHuaAppACChatModel;

public class LangHuaAppDanMuEvent {
    private LangHuaAppACChatModel chatModel;

    public LangHuaAppDanMuEvent(LangHuaAppACChatModel chatModel) {
        this.chatModel = chatModel;
    }

    public LangHuaAppACChatModel getChatModel() {
        return chatModel;
    }

    public void setChatModel(LangHuaAppACChatModel chatModel) {
        this.chatModel = chatModel;
    }
}