package com.mingquan.yuejian.adapter;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserReleationInfoModel;
import com.mingquan.yuejian.widget.LangHuaAppAvatarView;
import com.mingquan.yuejian.widget.LangHuaAppStatusTextView;

import java.util.List;

/**
 *
 */
public class LangHuaAppUserBaseInfoAdapter extends BaseAdapter {
    private List<LangHuaAppACUserReleationInfoModel> users;
    private Activity mActivity;

    public LangHuaAppUserBaseInfoAdapter(List<LangHuaAppACUserReleationInfoModel> users, Activity activity) {
        this.users = users;
        mActivity = activity;
    }

    @Override
    public int getCount() {
        return users.size();
    }

    @Override
    public Object getItem(int position) {
        return users.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        LangHuaAppACUserReleationInfoModel model = users.get(position);
        if (convertView == null) {
            convertView = View.inflate(LangHuaAppAppContext.getInstance(), R.layout.lang_hua_app_item_attention, null);
            viewHolder = new ViewHolder();
            viewHolder.avatar = (LangHuaAppAvatarView) convertView.findViewById(R.id.avatar);
            viewHolder.name = (TextView) convertView.findViewById(R.id.tv_name);
            viewHolder.love_num = (TextView) convertView.findViewById(R.id.love_num);
            viewHolder.status = (LangHuaAppStatusTextView) convertView.findViewById(R.id.stv_status);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.status.setStatus(model.getUser().getStatus(), model.getUser().getStatusTag());
        viewHolder.avatar.setAvatarUrl(model.getUser().getAvatarUrl());
        viewHolder.name.setText(model.getUser().getName());
        viewHolder.love_num.setText(model.getUser().getUid());
        return convertView;
    }

    class ViewHolder {
        LangHuaAppAvatarView avatar;
        TextView name;
        TextView love_num;
        public LangHuaAppStatusTextView status;
    }
}
