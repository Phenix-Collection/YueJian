package com.mingquan.yuejian.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.base.LangHuaAppFullScreenModeActivity;
import com.mingquan.yuejian.em.LangHuaAppChangInfo;
import com.mingquan.yuejian.proto.LangHuaAppApiProtoHelper;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserPublicInfoModel;
import com.mingquan.yuejian.ui.dialog.LangHuaAppEditableActionSheetDialog;
import com.mingquan.yuejian.utils.LangHuaAppTLog;
import com.mingquan.yuejian.utils.LangHuaAppUIHelper;
import com.mingquan.yuejian.utils.LangHuaAppUtils;
import com.mingquan.yuejian.vchat.LangHuaAppXTemplateTitle;
import com.mingquan.yuejian.widget.LangHuaAppAvatarView;
import com.umeng.analytics.MobclickAgent;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by Administrator on 2016/3/9.
 */
public class LangHuaAppMyInfoDetailActivity extends LangHuaAppFullScreenModeActivity implements View.OnClickListener {
    @BindView(R.id.title_layout)
    LangHuaAppXTemplateTitle titleLayout;
    @BindView(R.id.rl_userHead)
    RelativeLayout mRlUserHead;
    @BindView(R.id.rl_userNick)
    RelativeLayout mRlUserNick;
    @BindView(R.id.rl_userSign)
    RelativeLayout mRlUserSign;
    @BindView(R.id.rl_userSex)
    RelativeLayout mRlUserSex;
    @BindView(R.id.tv_userNick)
    TextView mUserNick;
    @BindView(R.id.tv_sign)
    TextView mUserSign;
    @BindView(R.id.av_userHead)
    LangHuaAppAvatarView mUserHead;
    @BindView(R.id.tv_sex)
    TextView mSex;

    private LangHuaAppACUserPublicInfoModel mUser;
    private Unbinder unbinder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lang_hua_app_activity_myinfo_detail);
        unbinder = ButterKnife.bind(this);
        initView();
    }

    public void initView() {
        titleLayout.setLeftBtnListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        mRlUserNick.setOnClickListener(this);
        mRlUserSign.setOnClickListener(this);
        mRlUserHead.setOnClickListener(this);
        mRlUserSex.setOnClickListener(this);
        mUserHead.setOnClickListener(this); //增加头像事件监听
    }

    @Override
    public void onClick(View v) {
        if (mUser != null) {
            switch (v.getId()) {
                case R.id.rl_userNick:
                    LangHuaAppUIHelper.showEditInfoActivity(this, "修改昵称", getString(R.string.editnickpromp),
                            mUser.getName(), LangHuaAppChangInfo.CHANG_NICK);
                    break;
                case R.id.rl_userSign:
                    LangHuaAppUIHelper.showEditInfoActivity(this, "修改签名", getString(R.string.editsignpromp),
                            mUser.getSignature(), LangHuaAppChangInfo.CHANG_SIGN);
                    break;
                case R.id.rl_userHead:
                    LangHuaAppUIHelper.showSelectAvatar(this, mUser.getAvatarUrl());
                    break;
                case R.id.rl_userSex:
                    if (LangHuaAppUtils.isFastClick()) {
                        return;
                    }
                    showSelectSex();
                    break;
                case R.id.av_userHead:
                    LangHuaAppUIHelper.showSelectAvatar(this, mUser.getAvatarUrl()); //选择头像
                    break;
            }
        }
    }

    /**
     * 弹出选择性别窗口
     */
    private void showSelectSex() {
        final LangHuaAppEditableActionSheetDialog mDialog = new LangHuaAppEditableActionSheetDialog(this).builder();
        TextView manTextView = new TextView(this);
        TextView womenTextView = new TextView(this);
        mDialog.addSheetItem(manTextView, "男", LangHuaAppEditableActionSheetDialog.SheetItemColor.Blue,
                new LangHuaAppEditableActionSheetDialog.OnSheetItemClickListener() {
                    @Override
                    public void onClick(int which) {
                        mSex.setText("男");
                        LangHuaAppApiProtoHelper.sendACUpdateGenderReq(LangHuaAppMyInfoDetailActivity.this,
                                LangHuaAppAppContext.getInstance().getLoginUid(),
                                LangHuaAppAppContext.getInstance().getToken(), LangHuaAppApiProtoHelper.GENDER_MALE,
                                new LangHuaAppApiProtoHelper.ACUpdateGenderReqCallback() {
                                    @Override
                                    public void onError(int errCode, String errMessage) {
                                        LangHuaAppAppContext.showToastAppMsg(LangHuaAppMyInfoDetailActivity.this, "修改失败");
                                    }

                                    @Override
                                    public void onResponse(int gender) {
                                        mUser.setGender(gender);
                                        LangHuaAppAppContext.getInstance().updateAcPublicUser(mUser);
                                    }
                                });
                        mDialog.cancel();
                    }
                });
        mDialog.addSheetItem(womenTextView, "女", LangHuaAppEditableActionSheetDialog.SheetItemColor.Blue,
                new LangHuaAppEditableActionSheetDialog.OnSheetItemClickListener() {
                    @Override
                    public void onClick(int which) {
                        mSex.setText("女");
                        LangHuaAppApiProtoHelper.sendACUpdateGenderReq(LangHuaAppMyInfoDetailActivity.this,
                                LangHuaAppAppContext.getInstance().getLoginUid(),
                                LangHuaAppAppContext.getInstance().getToken(), LangHuaAppApiProtoHelper.GENDER_FEMALE,
                                new LangHuaAppApiProtoHelper.ACUpdateGenderReqCallback() {
                                    @Override
                                    public void onError(int errCode, String errMessage) {
                                        LangHuaAppAppContext.showToastAppMsg(LangHuaAppMyInfoDetailActivity.this, "修改失败");
                                    }

                                    @Override
                                    public void onResponse(int gender) {
                                        mUser.setGender(gender);
                                        LangHuaAppAppContext.getInstance().updateAcPublicUser(mUser);
                                    }
                                });
                        mDialog.cancel();
                    }
                });
        mDialog.show();
    }

    @Override
    protected void onStart() {
        mUser = LangHuaAppAppContext.getInstance().getAcPublicUser();
        LangHuaAppTLog.error("mUser:" + mUser);
        fillUI();
        super.onStart();
    }

    private void fillUI() {
        mUserNick.setText(mUser.getName());
        mUserSign.setText(mUser.getSignature());
        mUserHead.setAvatarUrl(mUser.getAvatarUrl());
        mSex.setText(mUser.getGender() == LangHuaAppApiProtoHelper.GENDER_MALE ? "男" : "女");
    }

    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart(
                "个人中心"); //统计页面(仅有Activity的应用中SDK自动调用，不需要单独写。"SplashScreen"为页面名称，可自定义)
        MobclickAgent.onResume(this); //统计时长
    }

    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("个人中心"); // （仅有Activity的应用中SDK自动调用，不需要单独写）保证
        // onPageEnd 在onPause 之前调用,因为 onPause
        // 中会保存信息。"SplashScreen"为页面名称，可自定义
        MobclickAgent.onPause(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbinder.unbind();
    }
}
