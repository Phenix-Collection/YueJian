package com.mingquan.yuejian.interf;

public interface LangHuaAppIBaseView {
    void initView();

    void initData();
}
