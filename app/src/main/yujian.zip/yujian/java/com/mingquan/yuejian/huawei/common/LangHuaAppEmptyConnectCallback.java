package com.mingquan.yuejian.huawei.common;

import com.huawei.hms.api.HuaweiApiClient;

/**
 * 连接client空回调
 */
public class LangHuaAppEmptyConnectCallback implements LangHuaAppIClientConnectCallback {

    private String msgPre;

    public LangHuaAppEmptyConnectCallback(String msgPre){
        this.msgPre = msgPre;
    }

    /**
     * HuaweiApiClient 连接结果回调
     *
     * @param rst    结果码
     * @param client HuaweiApiClient 实例
     */
    @Override
    public void onConnect(int rst, HuaweiApiClient client) {
        LangHuaAppHMSAgentLog.d(msgPre + rst);
    }
}