package com.mingquan.yuejian.WxPay;

import android.app.Activity;

import com.mingquan.yuejian.LangHuaAppAppConfig;
import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.fragment.LangHuaAppDiamondDialogFragment;
import com.mingquan.yuejian.proto.LangHuaAppApiProtoHelper;
import com.mingquan.yuejian.proto.model.LangHuaAppACWeixinPayDataModel;

/**
 * Created by Administrator on 2016/4/14.
 */
public class LangHuaAppWChatPayDiamondForFragment {
  IWXAPI msgApi;
  private Activity mPayActivity;
  private LangHuaAppDiamondDialogFragment mPayFragment;

  String nums = "";
  public LangHuaAppWChatPayDiamondForFragment(LangHuaAppDiamondDialogFragment fragment) {
    mPayFragment = fragment;
    this.mPayActivity = fragment.getActivity();
    msgApi = WXAPIFactory.createWXAPI(mPayActivity, null);
    // 将该app注册到微信
    msgApi.registerApp(LangHuaAppAppConfig.WCHAT_APP_ID);
  }

  /**
   * @param price 价格
   * @param num   数量
   * @dw 初始化微信支付
   */
  public void initPay(String price, String num, String itemId) {
    nums = num;
    LangHuaAppApiProtoHelper.sendACPayWithWeixinReq(mPayActivity, "" + LangHuaAppAppContext.getInstance().getLoginUid(),
        LangHuaAppAppContext.getInstance().getToken(), itemId, Integer.parseInt(price), 0,
        new LangHuaAppApiProtoHelper.ACPayWithWeixinReqCallback() {
          @Override
          public void onError(int errCode, String errMessage) {}

          @Override
          public void onResponse(LangHuaAppACWeixinPayDataModel data) {
            callWxPay(data);
          }
        });
  }

  private void callWxPay(LangHuaAppACWeixinPayDataModel info) {
    try {
      PayReq req = new PayReq();
      req.appId = info.getAppid();
      req.partnerId = info.getPartnerid();
      req.prepayId = info.getPrepayid(); //预支付会话ID
      req.packageValue = "Sign=WXPay";
      req.nonceStr = info.getNoncestr();
      req.timeStamp = String.valueOf(info.getTimestamp());
      req.sign = info.getSign();
      if (msgApi.sendReq(req)) {
        LangHuaAppAppContext.showToastAppMsg(mPayActivity, "微信支付");
      } else {
        LangHuaAppAppContext.showToastAppMsg(mPayActivity, "请查看您是否安装微信");
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
