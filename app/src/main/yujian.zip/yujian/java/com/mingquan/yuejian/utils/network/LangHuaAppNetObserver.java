package com.mingquan.yuejian.utils.network;

/**
 *网络状态相关 来自github
 */

public class LangHuaAppNetObserver {
  private static LangHuaAppINetStatusReceiver sGlobalReceiver;
  private static LangHuaAppINetStatusReceiver sNetStatusReceiver;

  /**
   * 注册全局回调,全局网络状态改变时,每次都会回调,主要用于设置全局网络状态使用
   * @param netStatusReceiver
   */
  public static synchronized void registerlGlobalReceiver(LangHuaAppINetStatusReceiver netStatusReceiver) {
    sGlobalReceiver = netStatusReceiver;
  }

  /**
   * 获取全局回调
   * @return
   */
  public static LangHuaAppINetStatusReceiver getGlobalReceiver() {
    return sGlobalReceiver;
  }

  /**
   * 取消注册的全局回调
   */
  public static void unGlobalRegister() {
    sGlobalReceiver = null;
  }

  /**
   * 注册回调
   * @param netStatusReceiver
   */
  public static synchronized void register(LangHuaAppINetStatusReceiver netStatusReceiver) {
    sNetStatusReceiver = netStatusReceiver;
  }

  /**
   * 取消
   */
  public static void unregister() {
    sNetStatusReceiver = null;
  }

  public static LangHuaAppINetStatusReceiver getNetStatusReceiver() {
    return sNetStatusReceiver;
  }
}
