package com.mingquan.yuejian.ui.dialog;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;

import com.mingquan.yuejian.R;
import com.mingquan.yuejian.fragment.LangHuaAppDiamondDialogFragment;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserPublicInfoModel;
import com.mingquan.yuejian.vchat.LangHuaAppAttentionDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppMyCallPriceDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppMyCollectionDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppMyInOutListDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppMyPackageDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppVChatAppointmentDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppVChatBindPhoneDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppVChatCommissionDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppVChatGiftContributionDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppVChatMessageDetailDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppVChatMyCallsDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppVChatOtherInfoDialogFragment;
import com.mingquan.yuejian.vchat.LangHuaAppVChatUserTagDialogFragment;

/**
 * Created by administrato on 2016/10/27.
 */

public class LangHuaAppDialogHelper {
    /**
     * 显示他人信息页面
     * Adair
     *
     * @param uid
     * @param manager
     */
    public static void showOtherInfoDialogFragment(int uid, FragmentManager manager) {

    }

    /**
     * 显示他人信息页面
     *
     * @param uid
     * @param manager
     */
    public static void showOtherInfoDialogFragment(String uid, FragmentManager manager) {

    }

    /***
     * 显示关注页面
     *
     * @param manager
     */
    public static void showAttentionDialogFragment(FragmentManager manager) {
        LangHuaAppAttentionDialogFragment attentionDialog = new LangHuaAppAttentionDialogFragment();
        attentionDialog.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        attentionDialog.show(manager, "LangHuaAppAttentionDialogFragment");
    }

    /**
     * 收支明细列表
     *
     * @param manager
     */
    public static void showMyDiamondListDialogFragment(FragmentManager manager) {
        LangHuaAppMyInOutListDialogFragment dialogFragment = new LangHuaAppMyInOutListDialogFragment();
        dialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        dialogFragment.show(manager, "LangHuaAppMyInOutListDialogFragment");
    }

    /**
     * 充值
     *
     * @return
     */
    public static void showRechargeDialogFragment(FragmentManager fragmentManager) {
        LangHuaAppDiamondDialogFragment diamondDialogFragment = new LangHuaAppDiamondDialogFragment();
        diamondDialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        diamondDialogFragment.show(fragmentManager, "LangHuaAppDiamondDialogFragment");
    }

    /**
     * 我的钱包
     *
     * @param manager
     */
    public static void showMyPackageDialogFragment(FragmentManager manager, int diamond, int ticket) {
        LangHuaAppMyPackageDialogFragment dialogFragment = new LangHuaAppMyPackageDialogFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("DIAMOND", diamond);
        bundle.putInt("TICKET", ticket);
        dialogFragment.setArguments(bundle);
        dialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        dialogFragment.show(manager, "LangHuaAppMyPackageDialogFragment");
    }

    /**
     * 我的通话
     *
     * @param manager
     */
    public static void showMyCallDialogFragment(FragmentManager manager) {
        LangHuaAppVChatMyCallsDialogFragment dialogFragment = new LangHuaAppVChatMyCallsDialogFragment();
        dialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        dialogFragment.show(manager, "LangHuaAppVChatMyCallsDialogFragment");
    }

    /**
     * 我的时长
     *
     * @param manager
     */
    public static void showMyTimeDialogFragment(FragmentManager manager) {
        LangHuaAppVChatMyCallsDialogFragment dialogFragment = new LangHuaAppVChatMyCallsDialogFragment();
        dialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        dialogFragment.show(manager, "LangHuaAppVChatMyCallsDialogFragment");
    }

    /**
     * 分成计划
     *
     * @param manager
     */
    public static void showCommissionDialogFragment(FragmentManager manager) {
        LangHuaAppVChatCommissionDialogFragment dialogFragment = new LangHuaAppVChatCommissionDialogFragment();
        dialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        dialogFragment.show(manager, "LangHuaAppVChatCommissionDialogFragment");
    }

    /**
     * 预约
     *
     * @param manager
     */
    public static void showAppointmentDialogFragment(FragmentManager manager) {
        LangHuaAppVChatAppointmentDialogFragment dialogFragment = new LangHuaAppVChatAppointmentDialogFragment();
        dialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        dialogFragment.show(manager, "LangHuaAppVChatAppointmentDialogFragment");
    }

    /**
     * 视频礼物榜
     *
     * @param manager
     */
    public static void showGiftContributionDialogFragment(FragmentManager manager) {
        LangHuaAppVChatGiftContributionDialogFragment dialogFragment = new LangHuaAppVChatGiftContributionDialogFragment();
        dialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        dialogFragment.show(manager, "LangHuaAppVChatGiftContributionDialogFragment");
    }

    /**
     * 我的收藏
     *
     * @param manager
     */
    public static void showMyCollectionDialogFragment(FragmentManager manager) {
        LangHuaAppMyCollectionDialogFragment dialogFragment = new LangHuaAppMyCollectionDialogFragment();
        dialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        dialogFragment.show(manager, "LangHuaAppMyCollectionDialogFragment");
    }

    /**
     * 绑定手机
     *
     * @param manager
     */
    public static void showBindPhoneDialogFragment(FragmentManager manager) {
        LangHuaAppVChatBindPhoneDialogFragment dialogFragment = new LangHuaAppVChatBindPhoneDialogFragment();
        dialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        dialogFragment.show(manager, "LangHuaAppVChatBindPhoneDialogFragment");
    }

    /**
     * 显示V聊详情页
     *
     * @param manager
     */
    public static void showVchatOtherInfoDialogFragment(FragmentManager manager, String uid) {
        LangHuaAppVChatOtherInfoDialogFragment vChatOtherInfoDialogFragment = new LangHuaAppVChatOtherInfoDialogFragment();
        vChatOtherInfoDialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        Bundle bundle = new Bundle();
        bundle.putString("UID", uid);
        vChatOtherInfoDialogFragment.setArguments(bundle);
        vChatOtherInfoDialogFragment.show(manager, "LangHuaAppVChatOtherInfoDialogFragment");
    }

    /**
     * 显示私信详情页
     *
     * @param manager
     */
    public static void showMessageDetailDialogFragment(FragmentManager manager, LangHuaAppACUserPublicInfoModel user) {
        LangHuaAppVChatMessageDetailDialogFragment vChatMessageDetailDialogFragment = new LangHuaAppVChatMessageDetailDialogFragment();
        vChatMessageDetailDialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        Bundle bundle = new Bundle();
        bundle.putSerializable("TARGET_USER", user);
        vChatMessageDetailDialogFragment.setArguments(bundle);
        vChatMessageDetailDialogFragment.show(manager, "LangHuaAppVChatMessageDetailDialogFragment");
    }

    /**
     * 显示用户标签页面
     *
     * @param manager
     */
    public static void showUserTagDialogFragment(FragmentManager manager, String targer_uid) {
        LangHuaAppVChatUserTagDialogFragment vChatUserTagDialogFragment = new LangHuaAppVChatUserTagDialogFragment();
        vChatUserTagDialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        Bundle bundle = new Bundle();
        bundle.putString("TARGET_UID", targer_uid);
        vChatUserTagDialogFragment.setArguments(bundle);
        vChatUserTagDialogFragment.show(manager, "LangHuaAppVChatUserTagDialogFragment");
    }

    /**
     * 设置视频聊天计费单价页面
     *
     * @param price
     */
    public static void showMyCallPriceDialogFragment(FragmentManager manager, int price) {
        LangHuaAppMyCallPriceDialogFragment dialogFragment = new LangHuaAppMyCallPriceDialogFragment();
        dialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        Bundle bundle = new Bundle();
        bundle.putInt("PRICE", price);
        dialogFragment.setArguments(bundle);
        dialogFragment.show(manager, "LangHuaAppMyCallPriceDialogFragment");
    }
}
