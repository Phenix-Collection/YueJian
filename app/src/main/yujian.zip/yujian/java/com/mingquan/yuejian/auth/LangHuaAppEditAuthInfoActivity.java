package com.mingquan.yuejian.auth;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.base.LangHuaAppFullScreenModeActivity;
import com.mingquan.yuejian.interf.LangHuaAppIBottomDialog;
import com.mingquan.yuejian.layoutmanager.LangHuaAppFullyGridLayoutManager;
import com.mingquan.yuejian.proto.LangHuaAppApiProtoHelper;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserPrivateInfoModel;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserPublicInfoModel;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserTagMetaDataModel;
import com.mingquan.yuejian.ui.dialog.LangHuaAppDialogHelper;
import com.mingquan.yuejian.ui.dialog.LangHuaAppEditableActionSheetDialog;
import com.mingquan.yuejian.utils.LangHuaAppDialogHelp;
import com.mingquan.yuejian.utils.LangHuaAppStringUtil;
import com.mingquan.yuejian.utils.LangHuaAppTLog;
import com.mingquan.yuejian.vchat.LangHuaAppLabelGroup;
import com.mingquan.yuejian.vchat.LangHuaAppXTemplateTitle;
import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.compress.Luban;
import com.luck.picture.lib.config.PictureConfig;
import com.luck.picture.lib.config.PictureMimeType;
import com.luck.picture.lib.entity.LocalMedia;
import com.qiniu.android.http.ResponseInfo;
import com.qiniu.android.storage.UpCompletionHandler;
import com.qiniu.android.storage.UpProgressHandler;
import com.qiniu.android.storage.UploadOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class LangHuaAppEditAuthInfoActivity extends LangHuaAppFullScreenModeActivity implements View.OnClickListener {

    @BindView(R.id.title_layout)
    LangHuaAppXTemplateTitle titleLayout;
    @BindView(R.id.ll_name)
    LinearLayout llName;
    @BindView(R.id.ll_phone_num)
    LinearLayout llPhoneNum;
    @BindView(R.id.ll_height)
    LinearLayout llHeight;
    @BindView(R.id.ll_weight)
    LinearLayout llWeight;
    @BindView(R.id.ll_sign)
    LinearLayout llSign;
    @BindView(R.id.ll_city)
    LinearLayout llCity;
    @BindView(R.id.ll_my_intro)
    LinearLayout llMyIntro;
    @BindView(R.id.ll_labels)
    LinearLayout llLabels;
    @BindView(R.id.ll_signature)
    LinearLayout llSigns;
    @BindView(R.id.btn_auth)
    Button btnAuth;
    @BindView(R.id.tv_name)
    TextView tvName;
    @BindView(R.id.tv_height)
    TextView tvHeight;
    @BindView(R.id.tv_weight)
    TextView tvWeight;
    @BindView(R.id.tv_sign)
    TextView tvSign;
    @BindView(R.id.tv_city)
    TextView tvCity;
    @BindView(R.id.tv_my_intro)
    TextView tvMyIntro;
    @BindView(R.id.tv_labels)
    TextView tvLabels;
    @BindView(R.id.tv_signature)
    TextView tvSignature;
    @BindView(R.id.label_container)
    LangHuaAppLabelGroup labelContainer;
    @BindView(R.id.rcv_picture)
    RecyclerView rcvPicture;
    @BindView(R.id.ll_id_card)
    LinearLayout llIdCard;
    @BindView(R.id.tv_id_card)
    TextView tvIdCard;
    @BindView(R.id.tv_phone_num)
    TextView tvPhoneNum;

    private int maxSelectNum = 8;
    private List<LocalMedia> selectList = new ArrayList<>();
    private LangHuaAppGridImageAdapter2 adapter;
    private PopupWindow pop;
    private String imageUploadToken;
    private JSONArray pictureKey = new JSONArray();
    private int sign_index;
    private String realName;
    private Toast toast;
    private LangHuaAppACUserPrivateInfoModel privateInfoModel;
    private LangHuaAppEditAuthInfoActivity mContext;
    private ArrayList<LangHuaAppACUserTagMetaDataModel> selfTagMetaDataModels = new ArrayList<>();
    private String[] signs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lang_hua_app_activity_edit_auth_info);
        mContext = LangHuaAppEditAuthInfoActivity.this;
        ButterKnife.bind(this);
        toast = Toast.makeText(LangHuaAppEditAuthInfoActivity.this, "", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        signs = getResources().getStringArray(R.array.sign);
        titleLayout.setLeftBtnListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        getImageUploadToken();
        initData();
    }


    private void getImageUploadToken() {
        LangHuaAppApiProtoHelper.sendACGetQiniuUploadTokenReq(
                this,
                LangHuaAppAppContext.getInstance().getLoginUid(),
                LangHuaAppAppContext.getInstance().getToken(),
                LangHuaAppApiProtoHelper.UPLOAD_FILE_AUTH_IMAGE,
                new LangHuaAppApiProtoHelper.ACGetQiniuUploadTokenReqCallback() {
                    @Override
                    public void onError(int errCode, String errMessage) {
                        LangHuaAppTLog.error(errMessage);
                    }

                    @Override
                    public void onResponse(String uploadToken) {
                        imageUploadToken = uploadToken;
                    }
                }
        );
    }

    private void initData() {
        privateInfoModel = LangHuaAppAppContext.getInstance().getPrivateInfoModel();
        if (privateInfoModel == null) {
            LangHuaAppApiProtoHelper.sendACGetUserPrivateInfoReq(
                    this,
                    LangHuaAppAppContext.getInstance().getLoginUid(),
                    LangHuaAppAppContext.getInstance().getToken(),
                    new LangHuaAppApiProtoHelper.ACGetUserPrivateInfoReqCallback() {
                        @Override
                        public void onError(int errCode, String errMessage) {
                            LangHuaAppTLog.error(errMessage);
                        }

                        @Override
                        public void onResponse(LangHuaAppACUserPrivateInfoModel user) {
                            LangHuaAppAppContext.getInstance().setPrivateInfo(user);
                            privateInfoModel = user;
                            fillUI();
                            initPictureGroup();
                        }
                    });
        } else {
            fillUI();
            initPictureGroup();
        }

        LangHuaAppApiProtoHelper.sendACGetUserPublicInfoReq(
                this,
                LangHuaAppAppContext.getInstance().getLoginUid(),
                new LangHuaAppApiProtoHelper.ACGetUserPublicInfoReqCallback() {
                    @Override
                    public void onError(int errCode, String errMessage) {
                        toast.setText(errMessage);
                        toast.show();
                    }

                    @Override
                    public void onResponse(LangHuaAppACUserPublicInfoModel user) {
                        tvName.setText(user.getName());
                        tvSignature.setText(user.getSignature());
                    }
                });
    }

    private void fillUI() {
        if (!LangHuaAppStringUtil.isEmpty(privateInfoModel.getMobile())) {
            tvPhoneNum.setText(privateInfoModel.getMobile());
        }
        if (!LangHuaAppStringUtil.isEmpty(privateInfoModel.getCerNo())) {
            tvIdCard.setText(privateInfoModel.getCerNo());
        }
        if (!LangHuaAppStringUtil.isEmpty(privateInfoModel.getHeight())) {
            tvHeight.setText(String.format("%sCM", privateInfoModel.getHeight()));
        }
        if (!LangHuaAppStringUtil.isEmpty(privateInfoModel.getWeight())) {
            tvWeight.setText(String.format("%sKG", privateInfoModel.getWeight()));
        }
        if (!LangHuaAppStringUtil.isEmpty(privateInfoModel.getSign())) {
            tvSign.setText(privateInfoModel.getSign());
            for (int i = 0; i < signs.length; i++) {
                sign_index = signs[i].equals(privateInfoModel.getSign()) ? i : 0;
            }
        }

        if (!LangHuaAppStringUtil.isEmpty(privateInfoModel.getCity())) {
            tvCity.setText(privateInfoModel.getCity());
        }
        if (!LangHuaAppStringUtil.isEmpty(privateInfoModel.getIntroduction())) {
            tvMyIntro.setText(privateInfoModel.getIntroduction());
        }
        if (!LangHuaAppStringUtil.isEmpty(privateInfoModel.getCity())) {
            tvCity.setText(privateInfoModel.getCity());
        }
        if (privateInfoModel.getTags() != 0) {
            getSelfTags(privateInfoModel.getTags());
            labelContainer.setLabels(selfTagMetaDataModels);
            tvLabels.setText("");
        }
    }

    /**
     * 获取自己的形象标签
     *
     * @param tags
     * @return
     */
    private void getSelfTags(int tags) {
        if ((tags & (tags - 1)) != 0) {
            for (int i = 0; i < 100; i++) {
                if (Math.pow(2, i) > tags) {
                    tags -= (int) Math.pow(2, i - 1);
                    getSelfTags(tags);
                    selfTagMetaDataModels.add(LangHuaAppAppContext.getInstance().getMyUserTagMetaByTagId((int) Math.pow(2, i - 1)));
                    break;
                }
            }
        } else {
            selfTagMetaDataModels.add(LangHuaAppAppContext.getInstance().getMyUserTagMetaByTagId(tags));
        }
    }

    private void initPictureGroup() {
        String images = privateInfoModel.getImagesJson();
        if (!LangHuaAppStringUtil.isEmpty(images)) {
            try {
                pictureKey = new JSONArray(images);
                LangHuaAppTLog.debug("picture key :%s", pictureKey.toString());
                for (int i = 0; i < pictureKey.length(); i++) {
                    LocalMedia localMedia = new LocalMedia();
                    localMedia.setCutPath((String) pictureKey.get(i));
                    localMedia.setPictureType("image");
                    selectList.add(localMedia);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        LangHuaAppFullyGridLayoutManager manager = new LangHuaAppFullyGridLayoutManager(this, 4, GridLayoutManager.VERTICAL, false);
        rcvPicture.setLayoutManager(manager);
        adapter = new LangHuaAppGridImageAdapter2(this, onAddPicClickListener);
        adapter.setList(selectList);
        adapter.setSelectMax(maxSelectNum);
        rcvPicture.setAdapter(adapter);
        adapter.setOnItemClickListener(new LangHuaAppGridImageAdapter2.OnItemClickListener() {
            @Override
            public void onItemClick(int position, View v) {
                if (selectList.size() > 0) {
                    LocalMedia media = selectList.get(position);
                    String pictureType = media.getPictureType();
                    int mediaType = PictureMimeType.pictureToVideo(pictureType);
                    switch (mediaType) {
                        case 1:
                            // 预览图片 可自定长按保存路径
                            //PictureSelector.create(LangHuaAppEditAuthInfoActivity.this).externalPicturePreview(position, "/custom_file", selectList);
                            PictureSelector.create(mContext).externalPicturePreview(position, selectList);
                            break;
                        /*case 2:
                            // 预览视频
                            PictureSelector.create(mContext).externalPictureVideo(media.getPath());
                            break;
                        case 3:
                            // 预览音频
                            PictureSelector.create(mContext).externalPictureAudio(media.getPath());
                            break;*/
                    }
                }
            }
        });

        adapter.setOnItemLongClickListener(new LangHuaAppGridImageAdapter2.OnItemLongClickListener() {
            @Override
            public void onItemLongClick(int position, View v) {
                showDeleteDialog(position);
            }
        });
    }

    private LangHuaAppGridImageAdapter2.onAddPicClickListener onAddPicClickListener = new LangHuaAppGridImageAdapter2.onAddPicClickListener() {

        @Override
        public void onAddPicClick() {

            //第一种方式，弹出选择和拍照的dialog
//            showPop();

            //第二种方式，直接进入相册，但是 是有拍照得按钮的
            //参数很多，根据需要添加

            PictureSelector.create(mContext)
                    .openGallery(PictureMimeType.ofImage())// 全部.PictureMimeType.ofAll()、图片.ofImage()、视频.ofVideo()、音频.ofAudio()
                    .imageSpanCount(4)// 每行显示个数
                    .selectionMode(PictureConfig.SINGLE)// 多选 or 单选PictureConfig.MULTIPLE : PictureConfig.SINGLE
                    .previewImage(true)// 是否可预览图片
                    .compressGrade(Luban.THIRD_GEAR)// luban压缩档次，默认3档 Luban.FIRST_GEAR、Luban.CUSTOM_GEAR
                    .isCamera(true)// 是否显示拍照按钮
                    .isZoomAnim(true)// 图片列表点击 缩放效果 默认true
                    .enableCrop(true)// 是否裁剪
                    .compress(true)// 是否压缩
                    .compressMode(PictureConfig.LUBAN_COMPRESS_MODE)//系统自带 or 鲁班压缩 PictureConfig.SYSTEM_COMPRESS_MODE or LUBAN_COMPRESS_MODE
                    .glideOverride(160, 160)// glide 加载宽高，越小图片列表越流畅，但会影响列表图片浏览的清晰度
                    .withAspectRatio(1, 1)// 裁剪比例 如16:9 3:2 3:4 1:1 可自定义
                    .rotateEnabled(false) // 裁剪是否可旋转图片
                    .forResult(PictureConfig.CHOOSE_REQUEST);//结果回调onActivityResult code
        }
    };

    /**
     * 弹出选择性别窗口
     */
    private void showDeleteDialog(final int position) {
        final LocalMedia localMedia = selectList.get(position);
        final LangHuaAppEditableActionSheetDialog mDialog = new LangHuaAppEditableActionSheetDialog(this).builder();
        TextView manTextView = new TextView(this);
        TextView delete = new TextView(this);
        mDialog.addSheetItem(manTextView, "设为封面", LangHuaAppEditableActionSheetDialog.SheetItemColor.Blue,
                new LangHuaAppEditableActionSheetDialog.OnSheetItemClickListener() {
                    @Override
                    public void onClick(int which) {
                        mDialog.cancel();
                        if (position == 0) {
                            return;
                        }

                        selectList.remove(localMedia);
                        selectList.add(0, localMedia);
                        adapter.notifyDataSetChanged();
                        sortPictureKey(position);
                    }
                });
        mDialog.addSheetItem(delete, "删除照片", LangHuaAppEditableActionSheetDialog.SheetItemColor.Blue,
                new LangHuaAppEditableActionSheetDialog.OnSheetItemClickListener() {
                    @Override
                    public void onClick(int which) {
                        LangHuaAppTLog.debug("select list remove");
                        selectList.remove(localMedia);
                        adapter.notifyDataSetChanged();
                        mDialog.cancel();
                        for (int i = 0; i < pictureKey.length(); i++) {
                            try {
                                if (localMedia.getCutPath().equals(pictureKey.get(i))) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                                        LangHuaAppTLog.debug("remove picture key");
                                        pictureKey.remove(i);
                                    }
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
        mDialog.show();
    }

    private void sortPictureKey(int index) {
        List<String> list = new ArrayList<>();
        LangHuaAppTLog.debug("sortPictureKey ---%s", pictureKey.toString());
        String str;
        for (int i = 0; i < pictureKey.length(); i++) {
            str = pictureKey.optString(i);
            list.add(str);
        }

        str = list.get(index);
        list.remove(index);
        list.add(0, str);

        //把数据放回去
        for (int i = 0; i < list.size(); i++) {
            str = list.get(i);
            try {
                pictureKey.put(i, str);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        LangHuaAppTLog.debug("sortPictureKey ---%s", pictureKey.toString());
    }

    private void showPop() {
        View bottomView = View.inflate(mContext, R.layout.lang_hua_app_layout_bottom_dialog, null);
        TextView mAlbum = (TextView) bottomView.findViewById(R.id.tv_album);
        TextView mCamera = (TextView) bottomView.findViewById(R.id.tv_camera);
        TextView mCancel = (TextView) bottomView.findViewById(R.id.tv_cancel);

        pop = new PopupWindow(bottomView, -1, -2);
        pop.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        pop.setOutsideTouchable(true);
        pop.setFocusable(true);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 0.5f;
        getWindow().setAttributes(lp);
        pop.setOnDismissListener(new PopupWindow.OnDismissListener() {

            @Override
            public void onDismiss() {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.alpha = 1f;
                getWindow().setAttributes(lp);
            }
        });
        pop.setAnimationStyle(R.style.main_menu_photo_anim);
        pop.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM, 0, 0);

        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.tv_album:
                        //相册
                        PictureSelector.create(mContext)
                                .openGallery(PictureMimeType.ofImage())
                                .maxSelectNum(maxSelectNum)
                                .minSelectNum(1)
                                .imageSpanCount(4)
                                .selectionMode(PictureConfig.MULTIPLE)
                                .forResult(PictureConfig.CHOOSE_REQUEST);
                        break;
                    case R.id.tv_camera:
                        //拍照
                        PictureSelector.create(mContext)
                                .openCamera(PictureMimeType.ofImage())
                                .forResult(PictureConfig.CHOOSE_REQUEST);
                        break;
                    case R.id.tv_cancel:
                        //取消
                        break;
                }
                closePopupWindow();
            }
        };

        mAlbum.setOnClickListener(clickListener);
        mCamera.setOnClickListener(clickListener);
        mCancel.setOnClickListener(clickListener);
    }

    public void closePopupWindow() {
        if (pop != null && pop.isShowing()) {
            pop.dismiss();
            pop = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        List<LocalMedia> images;
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case PictureConfig.CHOOSE_REQUEST:
                    // 图片选择结果回调

                    images = PictureSelector.obtainMultipleResult(data);
                    selectList.addAll(images);

                    // selectList = PictureSelector.obtainMultipleResult(data);
                    // 例如 LocalMedia 里面返回三种path
                    // 1.media.getPath(); 为原图path
                    // 2.media.getCutPath();为裁剪后path，需判断media.isCut();是否为true
                    // 3.media.getCompressPath();为压缩后path，需判断media.isCompressed();是否为true
                    // 如果裁剪并压缩了，以取压缩路径为准，因为是先裁剪后压缩的
                    LangHuaAppTLog.debug("image path:%s", images.get(0).getPath());
                    LangHuaAppTLog.debug("image compress path:%s", images.get(0).getCompressPath());
                    LangHuaAppTLog.debug("image cut path:%s", images.get(0).getCutPath());
                    LangHuaAppAppContext.getInstance().getUploadManager().put(
                            images.get(0).getCutPath(),
                            LangHuaAppAppContext.getInstance().getLoginUid() + "_" + System.currentTimeMillis(),
                            imageUploadToken,
                            completionHandler,
                            uploadOptions);
                    break;
            }
        }
    }

    private UpCompletionHandler completionHandler = new UpCompletionHandler() {
        @Override
        public void complete(String key, ResponseInfo info, JSONObject response) {
            try {
                if (response == null) {
                    LangHuaAppTLog.error("upload auth picture response == null!!");
                    return;
                }
                pictureKey.put(response.get("key"));
                LangHuaAppTLog.debug("pictureKey:%s", pictureKey.toString());
                if (info != null && info.isOK()) {
                    toast.setText("上传成功!");
                    toast.show();
                    adapter.setList(selectList);
                    adapter.notifyDataSetChanged();
                } else {
                    toast.setText("上传失败!");
                    toast.show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private UploadOptions uploadOptions = new UploadOptions(
            null,
            null,
            false,
            new UpProgressHandler() {
                @Override
                public void progress(String key, double percent) {
                    LangHuaAppTLog.debug("%s::::::::%s", key, percent);
                }
            }, null);

    @OnClick({
            R.id.ll_name, //昵称
            R.id.ll_phone_num, //手机号
            R.id.ll_id_card, // 身份证号
            R.id.ll_height, // 身高
            R.id.ll_weight, // 体重
            R.id.ll_sign, // 星座
            R.id.ll_city, // 城市
            R.id.ll_my_intro, // 个人简介
            R.id.ll_labels, // 形象标签
            R.id.ll_signature, // 签名
            R.id.btn_auth //提交认证
    })
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_name:
                LangHuaAppDialogHelp.showNameDialog(
                        mContext,
                        new LangHuaAppIBottomDialog() {
                            @Override
                            public void cancelDialog(Dialog d) {

                            }

                            @Override
                            public void determineDialog(Dialog d, Object... value) {
                                d.dismiss();
                                if (value[0].toString().length() <= 0) {
                                    return;
                                }
                                tvName.setText(value[0].toString());
                            }
                        });
                break;
            case R.id.ll_phone_num:
                if (LangHuaAppStringUtil.isEmpty(privateInfoModel.getMobile())) {
                    LangHuaAppDialogHelper.showBindPhoneDialogFragment(getSupportFragmentManager());
                } else {
                    toast.setText("已经绑定手机号！");
                    toast.show();
                }
                break;
            case R.id.ll_id_card:
                LangHuaAppDialogHelp.showIdCard(
                        mContext,
                        new LangHuaAppIBottomDialog() {
                            @Override
                            public void cancelDialog(Dialog d) {

                            }

                            @Override
                            public void determineDialog(Dialog d, Object... value) {
                                d.dismiss();
                                if (value[0].toString().length() <= 0) {
                                    return;
                                }
                                realName = (String) value[0];
                                tvIdCard.setText(value[1].toString());
                            }
                        });
                break;
            case R.id.ll_height:
                LangHuaAppDialogHelp.showHeightDialog(mContext, new LangHuaAppIBottomDialog() {
                    @Override
                    public void cancelDialog(Dialog d) {

                    }

                    @Override
                    public void determineDialog(Dialog d, Object... value) {
                        tvHeight.setText(value[0].toString());
                        d.dismiss();
                    }
                });

                break;
            case R.id.ll_weight:
                LangHuaAppDialogHelp.showWeightDialog(mContext, new LangHuaAppIBottomDialog() {
                    @Override
                    public void cancelDialog(Dialog d) {

                    }

                    @Override
                    public void determineDialog(Dialog d, Object... value) {
                        tvWeight.setText(value[0].toString());
                        d.dismiss();
                    }
                });
                break;
            case R.id.ll_sign:
                LangHuaAppDialogHelp.showSignDialog(mContext, new LangHuaAppIBottomDialog() {
                    @Override
                    public void cancelDialog(Dialog d) {

                    }

                    @Override
                    public void determineDialog(Dialog d, Object... value) {
                        sign_index = (int) value[0];
                        tvSign.setText(signs[sign_index]);
                        d.dismiss();
                    }
                });

                break;
            case R.id.ll_city:
                LangHuaAppDialogHelp.showCityDialog(mContext, new LangHuaAppIBottomDialog() {
                    @Override
                    public void cancelDialog(Dialog d) {

                    }

                    @Override
                    public void determineDialog(Dialog d, Object... value) {
                        tvCity.setText(value[0].toString());
                        d.dismiss();
                    }
                });
                break;
            case R.id.ll_my_intro:
                LangHuaAppDialogHelp.showMyIntroDialog(
                        mContext,
                        "可以介绍一下你自己",
                        "例：知名模特、演员",
                        new LangHuaAppIBottomDialog() {
                            @Override
                            public void cancelDialog(Dialog d) {

                            }

                            @Override
                            public void determineDialog(Dialog d, Object... value) {
                                d.dismiss();
                                if (value[0].toString().length() <= 0) {
                                    return;
                                }
                                tvMyIntro.setText(value[0].toString());
                            }
                        });
                break;
            case R.id.ll_labels:
                LangHuaAppDialogHelp.showMyLabelsDialog(
                        mContext,
                        new LangHuaAppIBottomDialog() {
                            @Override
                            public void cancelDialog(Dialog d) {

                            }

                            @Override
                            public void determineDialog(Dialog d, Object... value) {
                                d.dismiss();
                                List<LangHuaAppACUserTagMetaDataModel> labelsModel = (List<LangHuaAppACUserTagMetaDataModel>) value[0];
                                if (labelsModel.size() > 0) {
                                    labelContainer.setLabels(labelsModel);
                                    tvLabels.setText("");
                                }
                            }
                        });
                break;
            case R.id.ll_signature:
                LangHuaAppDialogHelp.showMyIntroDialog(
                        mContext,
                        "你希望大家和你面对面聊些什么？",
                        "随便什么话题都行",
                        new LangHuaAppIBottomDialog() {
                            @Override
                            public void cancelDialog(Dialog d) {

                            }

                            @Override
                            public void determineDialog(Dialog d, Object... value) {
                                d.dismiss();
                                if (value[0].toString().length() <= 0) {
                                    return;
                                }
                                tvSignature.setText(value[0].toString());
                            }
                        });
                break;
            case R.id.btn_auth:
                if (pictureKey.length() <= 0) {
                    toast.setText("请上传照片！！！");
                    toast.show();
                    return;
                }
                if (LangHuaAppStringUtil.isEmpty(tvName.getText().toString()) || tvName.getText().toString().equals("请输入昵称（必填）")) {
                    toast.setText("请输入昵称！！！");
                    toast.show();
                    return;
                }
                if (LangHuaAppStringUtil.isEmpty(tvPhoneNum.getText().toString()) || tvPhoneNum.getText().toString().equals("请输入手机号（必填）")) {
                    toast.setText("请输入手机号！！！");
                    toast.show();
                    return;
                }
                /*if (LangHuaAppStringUtil.isEmpty(tvIdCard.getText().toString()) || tvIdCard.getText().toString().equals("请输入身份证号（必填）")) {
                    toast.setText("请输入身份证号！！！");
                    toast.show();
                    return;
                }*/
                if (LangHuaAppStringUtil.isEmpty(tvHeight.getText().toString()) || tvHeight.getText().toString().equals("请设置身高（必填）")) {
                    toast.setText("请输入身高！！！");
                    toast.show();
                    return;
                }
                if (LangHuaAppStringUtil.isEmpty(tvWeight.getText().toString()) || tvWeight.getText().toString().equals("请设置体重（必填）")) {
                    toast.setText("请输入体重！！！");
                    toast.show();
                    return;
                }
                if (LangHuaAppStringUtil.isEmpty(tvSign.getText().toString()) || tvSign.getText().toString().equals("请设置星座（必填）")) {
                    toast.setText("请输入星座！！！");
                    toast.show();
                    return;
                }
                if (LangHuaAppStringUtil.isEmpty(tvCity.getText().toString()) || tvCity.getText().toString().equals("请设置城市（必填）")) {
                    toast.setText("请输入城市！！！");
                    toast.show();
                    return;
                }
                if (LangHuaAppStringUtil.isEmpty(tvMyIntro.getText().toString()) || tvMyIntro.getText().toString().equals("请编辑个人介绍（必填）")) {
                    toast.setText("请输入个人介绍！！！");
                    toast.show();
                    return;
                }
                if (labelContainer.getLabels().size() <= 0) {
                    toast.setText("请设置形象标签！！！");
                    toast.show();
                    return;
                }
                int tags_num = 0;
                for (int i = 0; i < labelContainer.getLabels().size(); i++) {
                    tags_num += ((LangHuaAppACUserTagMetaDataModel) labelContainer.getLabels().get(i)).getTagId();
                }

                String height = tvHeight.getText().toString().trim();
                String weight = tvWeight.getText().toString().trim();
                LangHuaAppApiProtoHelper.sendACUploadAuthInfoReq(
                        mContext,
                        LangHuaAppAppContext.getInstance().getLoginUid(),
                        LangHuaAppAppContext.getInstance().getToken(),
                        LangHuaAppStringUtil.encodeStr(tvName.getText().toString().trim()),
                        tvPhoneNum.getText().toString(),
                        Integer.parseInt(tvHeight.getText().toString().substring(0, height.length() - 2)),
                        Integer.parseInt(tvWeight.getText().toString().substring(0, weight.length() - 2)),
                        sign_index,
                        tvCity.getText().toString(),
                        LangHuaAppStringUtil.encodeStr(tvMyIntro.getText().toString().trim()),
                        tags_num,
                        LangHuaAppStringUtil.encodeStr(tvSignature.getText().toString().trim()),
                        "",
                        "",
                        pictureKey.toString(),
                        new LangHuaAppApiProtoHelper.ACUploadAuthInfoReqCallback() {
                            @Override
                            public void onError(int errCode, String errMessage) {
                                toast.setText(errMessage);
                                toast.show();
                            }

                            @Override
                            public void onResponse() {
                                toast.setText("提交审核成功！！！");
                                toast.show();
                                finish();
                            }
                        });
                break;
        }
    }

    public void setPhoneNum(String mPhoneNum) {
        this.tvPhoneNum.setText(mPhoneNum);
    }
}
