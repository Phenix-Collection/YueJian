package com.mingquan.yuejian.widget;

import android.content.Context;
import android.widget.BaseAdapter;
import android.widget.Toast;

import com.mingquan.yuejian.LangHuaAppAppConfig;
import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.proto.LangHuaAppApiProtoHelper;
import com.mingquan.yuejian.ui.view.LangHuaAppChatImageView;
import com.mingquan.yuejian.utils.LangHuaAppStringUtil;
import com.mingquan.yuejian.utils.LangHuaAppTLog;
import com.hyphenate.chat.EMClient;
import com.hyphenate.chat.EMImageMessageBody;
import com.hyphenate.chat.EMMessage;
import com.hyphenate.exceptions.HyphenateException;

/**
 * Created by sunzhenya
 * on 2016/11/25.
 */
public class LangHuaAppPhoneLiveChatRowImage extends LangHuaAppPhoneLiveChatRow {
  private LangHuaAppAvatarView mUhead;
  //    private LangHuaAppLoadUrlImageView mImage;
  private LangHuaAppChatImageView mImage;

  public LangHuaAppPhoneLiveChatRowImage(
      Context context, EMMessage message, int position, BaseAdapter adapter) {
    super(context, message, position, adapter);
  }

  @Override
  protected void onInflatView() {
    inflater.inflate(message.direct() == EMMessage.Direct.RECEIVE
            ? R.layout.lang_hua_app_item_message_left_image
            : R.layout.lang_hua_app_item_message_right_image,
        this);
  }

  @Override
  protected void onFindViewById() {
    mUhead = (LangHuaAppAvatarView) findViewById(R.id.av_message_head);
    mImage = (LangHuaAppChatImageView) findViewById(R.id.iv_message_image);
  }

  @Override
  protected void onUpdateView() {
    EMImageMessageBody body = (EMImageMessageBody) message.getBody();
    String toUid = message.getTo().replace(LangHuaAppAppConfig.IM_ACCOUNT, "");
    LangHuaAppTLog.info("image chat on update view from:%s, to:%s, imagePath:%s", message.getFrom(), toUid, body.getRemoteUrl());
    LangHuaAppApiProtoHelper.sendACSaveChatMessageReq(null,
            LangHuaAppAppContext.getInstance().getLoginUid(),
            LangHuaAppAppContext.getInstance().getToken(),
            toUid,
            LangHuaAppStringUtil.encodeStr(body.getRemoteUrl()),
            new LangHuaAppApiProtoHelper.ACSaveChatMessageReqCallback() {
              @Override
              public void onError(int errCode, String errMessage) {
                Toast.makeText(getContext().getApplicationContext(), errMessage, Toast.LENGTH_SHORT).show();
              }

              @Override
              public void onResponse() {
                LangHuaAppTLog.info("保存图片信息成功");
              }
            });
  }

  @Override
  protected void onSetUpView() {
    if (mUhead == null || message == null)
      return;
    EMImageMessageBody imageBody = (EMImageMessageBody) message.getBody();
    try {
      if (message.getFrom().equals("admin")) {
        mUhead.setBackgroundResource(R.drawable.lang_hua_app_ic_launcher);
      } else {
        mUhead.setAvatarUrl(message.getStringAttribute("uhead"));
      }
      if (message.direct() == EMMessage.Direct.SEND) {
        if (!imageBody.getThumbnailUrl().isEmpty()) {
          mImage.setImageLoadUrl(imageBody.getThumbnailUrl());
        } else {
          if (!imageBody.getRemoteUrl().isEmpty()) {
            mImage.setImageLoadUrl(imageBody.getRemoteUrl());
          } else {
            mImage.setImageLoadUrl(imageBody.getLocalUrl());
          }
        }
      } else {
        mImage.setImageLoadUrl(imageBody.getThumbnailUrl());
      }

    } catch (HyphenateException e) {
      e.printStackTrace();
    }
    handleTextMessage();
  }

  protected void handleTextMessage() {
    if (message.direct() == EMMessage.Direct.SEND) {
      setMessageSendCallback();
      switch (message.status()) {
        case CREATE:
          // 发送消息
          //                sendMsgInBackground(message);
          break;
        case SUCCESS: // 发送成功
          break;
        case FAIL: // 发送失败
          break;
        case INPROGRESS: // 发送中
          break;
        default:
          break;
      }
    } else {
      if (!message.isAcked() && message.getChatType() == EMMessage.ChatType.Chat) {
        try {
          EMClient.getInstance().chatManager().ackMessageRead(
              message.getFrom(), message.getMsgId());
        } catch (HyphenateException e) {
          e.printStackTrace();
        }
      }
    }
  }

  @Override
  protected void onBubbleClick() {}
}
