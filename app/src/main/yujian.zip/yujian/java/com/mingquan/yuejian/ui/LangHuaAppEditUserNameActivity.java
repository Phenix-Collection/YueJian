package com.mingquan.yuejian.ui;

import android.view.View;

import com.mingquan.yuejian.R;
import com.mingquan.yuejian.base.LangHuaAppBaseActivity;

public class LangHuaAppEditUserNameActivity extends LangHuaAppBaseActivity {
  @Override
  protected int getLayoutId() {
    return R.layout.lang_hua_app_activity_edit_user_name;
  }

  @Override
  public void onClick(View v) {}

  @Override
  public void initView() {}

  @Override
  public void initData() {}
}
