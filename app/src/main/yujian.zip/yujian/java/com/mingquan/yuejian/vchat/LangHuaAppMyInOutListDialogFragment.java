package com.mingquan.yuejian.vchat;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.fragment.LangHuaAppBaseDialogFragment;
import com.mingquan.yuejian.proto.LangHuaAppApiProtoHelper;
import com.mingquan.yuejian.proto.model.LangHuaAppACConsumptionInfoModel;
import com.mingquan.yuejian.utils.LangHuaAppTimeFormater;
import com.mingquan.yuejian.widget.LangHuaAppAvatarView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by sun on 2018/9/4.
 * <p>
 * 我的收支明细页面
 */

public class LangHuaAppMyInOutListDialogFragment extends LangHuaAppBaseDialogFragment {

    @BindView(R.id.title_layout)
    LangHuaAppXTemplateTitle titleLayout;
    @BindView(R.id.list_view)
    ListView listView;
    Unbinder unbinder;
    @BindView(R.id.sr_refresh)
    SwipeRefreshLayout srRefresh;
    private DiamondAdapter mAdapter;
    private Context mContext;
    private int mLastQueryId = 0;
    private List<LangHuaAppACConsumptionInfoModel> mConsumptions;

    @Nullable
    @Override
    public View onCreateView(
            LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.lang_hua_app_fragment_my_diamond_list, null);
        unbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContext = getActivity();
        mConsumptions = new ArrayList<>();
        mAdapter = new DiamondAdapter();
        listView.setAdapter(mAdapter);
        initView();
        requestData();
    }

    public void initView() {
        titleLayout.setLeftBtnListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        srRefresh.setColorSchemeColors(getResources().getColor(R.color.home_pink));
        srRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mLastQueryId = 0;
                requestData();
            }
        });
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == mConsumptions.size() - 1) {
                        requestData();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });
    }

    /**
     * 请求收支明细数据
     */
    private void requestData() {
        LangHuaAppApiProtoHelper.sendACGetConsumptionInfoReq(
                (Activity) mContext,
                LangHuaAppAppContext.getInstance().getLoginUid(),
                LangHuaAppAppContext.getInstance().getToken(),
                10,
                mLastQueryId,
                new LangHuaAppApiProtoHelper.ACGetConsumptionInfoReqCallback() {
                    @Override
                    public void onError(int errCode, String errMessage) {
                        if (srRefresh != null && srRefresh.isRefreshing()) {
                            srRefresh.setRefreshing(false);
                        }
                    }

                    @Override
                    public void onResponse(ArrayList<LangHuaAppACConsumptionInfoModel> consumptions, int lastQueryId) {

                        if (srRefresh != null && srRefresh.isRefreshing()) {
                            srRefresh.setRefreshing(false);
                            mConsumptions.clear();
                        }
                        mLastQueryId = lastQueryId;
                        mConsumptions.addAll(consumptions);
                        mAdapter.notifyDataSetChanged();
                    }
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    private class DiamondAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return mConsumptions.size();
        }

        @Override
        public Object getItem(int i) {
            return mConsumptions.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.lang_hua_app_item_my_diamond_list, null);
                viewHolder = new ViewHolder();
                viewHolder.tvTime = (TextView) convertView.findViewById(R.id.tv_time);
                viewHolder.tvDate = (TextView) convertView.findViewById(R.id.tv_date);
                viewHolder.tvPayNum = (TextView) convertView.findViewById(R.id.tv_pay_num);
                viewHolder.tvUnit = (TextView) convertView.findViewById(R.id.tv_unit);
                viewHolder.tvPayName = (TextView) convertView.findViewById(R.id.tv_pay_name);
                viewHolder.tvBroadcastName = (TextView) convertView.findViewById(R.id.tv_broadcast_name);
                viewHolder.broadcastAvatar = (LangHuaAppAvatarView) convertView.findViewById(R.id.broadcast_avatar);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            LangHuaAppACConsumptionInfoModel model = mConsumptions.get(position);
            if (model.getAmount() > 0) {
                viewHolder.tvPayNum.setText(String.format("+%d", model.getAmount()));
                viewHolder.tvPayNum.setTextColor(Color.parseColor("#ec6997"));
            } else {
                viewHolder.tvPayNum.setText(String.valueOf(model.getAmount()));
                viewHolder.tvPayNum.setTextColor(Color.parseColor("#4e80f7"));
            }
            switch (model.getConsumptionType()) {
                case LangHuaAppApiProtoHelper.DIAMOND_INPUT_CHARGE:
                case LangHuaAppApiProtoHelper.DIAMOND_INPUT_ACTIVITY_AGENT_INVITE_USER:
                case LangHuaAppApiProtoHelper.DIAMOND_INPUT_ACTIVITY_BE_INVITED_BY_AGENT:
                case LangHuaAppApiProtoHelper.DIAMOND_INPUT_TESTING:
                case LangHuaAppApiProtoHelper.DIAMOND_OUTPUT_BUY_VIDEO:
                case LangHuaAppApiProtoHelper.DIAMOND_OUTPUT_VIDEO_CHAT:
                case LangHuaAppApiProtoHelper.DIAMOND_OUTPUT_SEND_GIFT:
                case LangHuaAppApiProtoHelper.DIAMOND_OUTPUT_SEND_MESSAGE:
                case LangHuaAppApiProtoHelper.DIAMOND_OUTPUT_TESTING:
                case LangHuaAppApiProtoHelper.DIAMOND_INPUT_ACTIVITY_BE_INVITED_BY_PARTNER:
                case LangHuaAppApiProtoHelper.DIAMOND_INPUT_ACTIVITY_FREE_TRIAL:
                case LangHuaAppApiProtoHelper.DIAMOND_INPUT_ADMIN:
                    viewHolder.tvUnit.setText("钻石");
                    break;
                case LangHuaAppApiProtoHelper.TICKET_INPUT_SELL_VIDEO:
                case LangHuaAppApiProtoHelper.TICKET_INPUT_VIDEO_CHAT:
                case LangHuaAppApiProtoHelper.TICKET_INPUT_RECEIVE_GIFT:
                case LangHuaAppApiProtoHelper.TICKET_INPUT_RECEIVE_MESSAGE:
                case LangHuaAppApiProtoHelper.TICKET_INPUT_TESTING:
                case LangHuaAppApiProtoHelper.TICKET_OUTPUT_TESTING:
                    viewHolder.tvUnit.setText("趣票");
                    break;
            }
            viewHolder.tvPayName.setText(model.getDesp());
            viewHolder.tvTime.setText(LangHuaAppTimeFormater.timeToStrLong((long) model.getConsumptionTime() * 1000));
            viewHolder.tvDate.setText(LangHuaAppTimeFormater.timeToStrLong2((long) model.getConsumptionTime() * 1000));
            viewHolder.tvBroadcastName.setText(model.getTarget().getName());
            viewHolder.broadcastAvatar.setAvatarUrl(model.getTarget().getAvatarUrl());
            return convertView;
        }
    }

    private class ViewHolder {
        TextView tvTime; // 时间
        TextView tvDate; // 日期
        TextView tvPayNum; // 收支钻石数
        TextView tvUnit; // 收支单位（钻石或趣票）
        TextView tvPayName; // 收支类型
        TextView tvBroadcastName; // 主播昵称
        LangHuaAppAvatarView broadcastAvatar; // 主播头像
    }
}

