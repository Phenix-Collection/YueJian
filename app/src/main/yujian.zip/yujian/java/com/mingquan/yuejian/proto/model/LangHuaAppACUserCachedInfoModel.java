/*
 * Copyright (C) 2017 QR Co. All rights reserved.
 *
 * Created by tool, DO NOT EDIT!!!
 */

package com.mingquan.yuejian.proto.model;

import com.mingquan.yuejian.utils.LangHuaAppRavenUtils;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

/**
 * LangHuaAppACUserCachedInfoModel
 */
public class LangHuaAppACUserCachedInfoModel implements Serializable {
    private LangHuaAppACUserPublicInfoModel publicData; // 用户的公开信息
    private LangHuaAppACUserPrivateInfoModel privateData; // 用户的私有本信息
    private LangHuaAppACUserSettingsModel settings; // 个人配置信息
    private LangHuaAppACServerConfigModel serverConfig; // 服务器配置选项
    private String token; // 用户的私有本信息

    /**
     * ACUserCachedInfoModel的构造函数
     * @param json json数据源
     */
    public LangHuaAppACUserCachedInfoModel(JSONObject json) {
        // 设置默认值
        this.publicData = new LangHuaAppACUserPublicInfoModel(null); // 用户的公开信息
        this.privateData = new LangHuaAppACUserPrivateInfoModel(null); // 用户的私有本信息
        this.settings = new LangHuaAppACUserSettingsModel(null); // 个人配置信息
        this.serverConfig = new LangHuaAppACServerConfigModel(null); // 服务器配置选项
        this.token = ""; // 用户的私有本信息

        // 解析JSON数据
        String current_field_name = "";
        try {
            if (json != null) {
                // 用户的公开信息
                current_field_name = "public_data";
                if (json.has("public_data")) {
                    this.publicData = new LangHuaAppACUserPublicInfoModel(json.getJSONObject("public_data"));
        
                }
    
                // 用户的私有本信息
                current_field_name = "private_data";
                if (json.has("private_data")) {
                    this.privateData = new LangHuaAppACUserPrivateInfoModel(json.getJSONObject("private_data"));
        
                }
    
                // 个人配置信息
                current_field_name = "settings";
                if (json.has("settings")) {
                    this.settings = new LangHuaAppACUserSettingsModel(json.getJSONObject("settings"));
        
                }
    
                // 服务器配置选项
                current_field_name = "server_config";
                if (json.has("server_config")) {
                    this.serverConfig = new LangHuaAppACServerConfigModel(json.getJSONObject("server_config"));
        
                }
    
                // 用户的私有本信息
                current_field_name = "token";
                if (json.has("token")) {
                    this.token = json.getString("token");
                }
    
            }
        } catch (Exception e) {
          HashMap<String, Object> extension = new HashMap<>();
            extension.put("model", "LangHuaAppACUserCachedInfoModel");
            extension.put("field", current_field_name);
            LangHuaAppRavenUtils.logException("解析JSON数据失败", e, extension);
        }
    }
    
    /**
     * 用户的公开信息
     */
    public LangHuaAppACUserPublicInfoModel getPublicData() { return publicData; }
    public void setPublicData(LangHuaAppACUserPublicInfoModel value) { this.publicData = value; }
    
    /**
     * 用户的私有本信息
     */
    public LangHuaAppACUserPrivateInfoModel getPrivateData() { return privateData; }
    public void setPrivateData(LangHuaAppACUserPrivateInfoModel value) { this.privateData = value; }
    
    /**
     * 个人配置信息
     */
    public LangHuaAppACUserSettingsModel getSettings() { return settings; }
    public void setSettings(LangHuaAppACUserSettingsModel value) { this.settings = value; }
    
    /**
     * 服务器配置选项
     */
    public LangHuaAppACServerConfigModel getServerConfig() { return serverConfig; }
    public void setServerConfig(LangHuaAppACServerConfigModel value) { this.serverConfig = value; }
    
    /**
     * 用户的私有本信息
     */
    public String getToken() { return token; }
    public void setToken(String value) { this.token = value; }
    

    @Override
    public String toString() {
        return "LangHuaAppACUserCachedInfoModel{" +
                "publicData=" + publicData +
                ", privateData=" + privateData +
                ", settings=" + settings +
                ", serverConfig=" + serverConfig +
                ", token='" + token + '\'' +
                '}';
    }

    
}