package com.mingquan.yuejian;

/**
 * Created by administrato on 2017/2/24.
 */

public class LangHuaAppAPPRes {
  /*告白气球*/
  public static final String ASSET_FILE_BALLOON_JSON_00 = "balloon/love-0.json";
  public static final String ASSET_FILE_BALLOON_JSON_01 = "balloon/love-1.json";
  public static final String ASSET_FILE_BALLOON_JSON_02 = "balloon/love-2.json";
  public static final String ASSET_FILE_BALLOON_JSON_03 = "balloon/love-3.json";
  public static final String ASSET_FILE_BALLOON_PNG_00 = "balloon/love0.png";
  public static final String ASSET_FILE_BALLOON_PNG_01 = "balloon/love1.png";
  public static final String ASSET_FILE_BALLOON_PNG_02 = "balloon/love2.png";
  public static final String ASSET_FILE_BALLOON_PNG_03 = "balloon/love3.png";

  /*幸运Lucky礼物资源*/
  public static final String ASSET_FILE_LUCKY_JSON_00 = "lucky/lucky-0.json";

  public static final String ASSET_FILE_LUCKY_PNG_00 = "lucky/lucky0.png";

  /*大礼物资源*/
  public static final String ASSET_FILE_GREEN_BOX_JSON_00 = "green_box/green_box-0.json";
  public static final String ASSET_FILE_GREEN_BOX_PNG_00 = "green_box/green_box0.png";
  public static final String ASSET_FILE_PURPLE_BOX_JSON_00 = "purple_box/purple_box-0.json";
  public static final String ASSET_FILE_PURPLE_BOX_PNG_00 = "purple_box/purple_box0.png";
  public static final String ASSET_FILE_YELLOW_BOX_JSON_00 = "yellow_box/yellow_box-0.json";
  public static final String ASSET_FILE_YELLOW_BOX_PNG_00 = "yellow_box/yellow_box0.png";

  public static final String SUBFIX_TXT=".txt";
  public static final String SUBFIX_JSON =".json";
  public static final String BASE_64 ="b64";
  public static final String JSON ="json";
}
