package com.mingquan.yuejian.vchat;

import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;

import com.mingquan.yuejian.utils.LangHuaAppTLog;

import java.util.List;

public class LangHuaAppVideoLayoutAdapter extends PagerAdapter {

    private List<View> mViews;

    public LangHuaAppVideoLayoutAdapter(List<View> views) {
        this.mViews = views;
    }


    public void setViews(List<View> mViews) {
        this.mViews = mViews;
    }

    @Override
    public int getCount() {
        return mViews.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LangHuaAppTLog.debug("instantiateItem: position:%s", position);
        container.addView(mViews.get(position));
        return mViews.get(position);
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        LangHuaAppTLog.debug("destroyItem: position:%s", position);
        container.removeView(mViews.get(position));
    }
}