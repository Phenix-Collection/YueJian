package com.mingquan.yuejian.interf;

import android.view.View;

/**
 * Created by Administrator on 2016/4/11.
 */
public interface LangHuaAppIPagerSlidingClickListener {
  void onItemClick(View v, int currentPosition, int position);
}
