package com.mingquan.yuejian.huawei.common;

/**
 * 回调接口
 */
public interface LangHuaAppICallbackCode {
    /**
     * 回调接口
     * @param rst 结果码
     */
    void onResult(int rst);
}
