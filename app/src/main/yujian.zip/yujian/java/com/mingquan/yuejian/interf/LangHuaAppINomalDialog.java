package com.mingquan.yuejian.interf;

import android.app.Dialog;
import android.view.View;

/**
 * Created by Administrator on 2016/3/19.
 */
public interface LangHuaAppINomalDialog {
  void cancelDialog(View v, Dialog d);

  void determineDialog(View v, Dialog d);
}
