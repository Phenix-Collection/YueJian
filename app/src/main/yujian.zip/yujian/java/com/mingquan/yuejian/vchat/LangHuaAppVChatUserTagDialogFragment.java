package com.mingquan.yuejian.vchat;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.fragment.LangHuaAppBaseDialogFragment;
import com.mingquan.yuejian.model.LangHuaAppUserTagAndCountModel;
import com.mingquan.yuejian.proto.LangHuaAppApiProtoHelper;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserTagModel;
import com.mingquan.yuejian.utils.LangHuaAppTLog;

import java.util.ArrayList;

/**
 * Created by Administrator on 2018/9/29
 * <p>
 * 用户印象标签
 */

public class LangHuaAppVChatUserTagDialogFragment extends LangHuaAppBaseDialogFragment {

    private LangHuaAppXTemplateTitle titleLayout;
    private LangHuaAppLabelGroup labelContainer;
    private TextView tvEmptyTips;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.lang_hua_app_fragment_vchat_user_tag, null);
        titleLayout = (LangHuaAppXTemplateTitle) view.findViewById(R.id.title_layout);
        labelContainer = (LangHuaAppLabelGroup) view.findViewById(R.id.label_container);
        tvEmptyTips = (TextView) view.findViewById(R.id.tv_empty_tips);
        titleLayout.setLeftBtnListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initData();
    }

    private void initData() {
        String target_uid = getArguments().getString("TARGET_UID");
        LangHuaAppApiProtoHelper.sendACGetUserTagsBriefReq(getActivity(), target_uid, new LangHuaAppApiProtoHelper.ACGetUserTagsBriefReqCallback() {
            @Override
            public void onError(int errCode, String errMessage) {

            }

            @Override
            public void onResponse(ArrayList<LangHuaAppACUserTagModel> tags) {
                if (tags.size() == 0) {
                    LangHuaAppTLog.debug("没有标签");
                    tvEmptyTips.setText("暂时还没有用户标签");
                    return;
                }

                ArrayList<LangHuaAppUserTagAndCountModel> userTagAndCountModels = new ArrayList<>();
                for (LangHuaAppACUserTagModel model : tags) {
                    LangHuaAppUserTagAndCountModel userTagAndCountModel = new LangHuaAppUserTagAndCountModel();
                    userTagAndCountModel.setCount(model.getCount());
                    userTagAndCountModel.setMetaDataModel(LangHuaAppAppContext.getInstance().getUserTagMetaByTagId(model.getTagId()));
                    userTagAndCountModels.add(userTagAndCountModel);
                }

                labelContainer.setLabels(userTagAndCountModels);
            }
        });
    }
}
