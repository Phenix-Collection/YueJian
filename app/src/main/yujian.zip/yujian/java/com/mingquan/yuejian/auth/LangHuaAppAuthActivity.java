package com.mingquan.yuejian.auth;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.base.LangHuaAppFullScreenModeActivity;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserPrivateInfoModel;
import com.mingquan.yuejian.utils.LangHuaAppStringUtil;
import com.mingquan.yuejian.utils.LangHuaAppUIHelper;
import com.mingquan.yuejian.vchat.LangHuaAppXTemplateTitle;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Administrator on 2018/10/24
 */
public class LangHuaAppAuthActivity extends LangHuaAppFullScreenModeActivity {

    @BindView(R.id.title_layout)
    LangHuaAppXTemplateTitle titleLayout;
    @BindView(R.id.btn_to_auth)
    Button btnToAuth;
    @BindView(R.id.tv_description)
    TextView tvDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lang_hua_app_activity_auth);
        ButterKnife.bind(this);
        LangHuaAppACUserPrivateInfoModel privateInfoModel = LangHuaAppAppContext.getInstance().getPrivateInfoModel();
        if (privateInfoModel != null && !LangHuaAppStringUtil.isEmpty(privateInfoModel.getAuthComment())) {
            tvDescription.setText(privateInfoModel.getAuthComment());
        }
        initEvent();
    }

    public void initEvent() {
        titleLayout.setLeftBtnListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnToAuth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LangHuaAppUIHelper.showEditAuthinfoActivity(LangHuaAppAuthActivity.this);
            }
        });
    }
}
