package com.mingquan.yuejian.auth;

/**
 * Created by Administrator on 2016/9/27 0027.
 */

public interface LangHuaAppIWheelAreaPicker {
    String getCountry();
    String getProvince();

    String getCity();


    void hideArea();
}
