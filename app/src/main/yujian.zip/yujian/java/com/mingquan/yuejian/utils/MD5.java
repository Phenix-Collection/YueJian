package com.mingquan.yuejian.utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import android.text.TextUtils;

public class MD5 {
  private static final char HEX_DIGITS[] = {
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

  public static void main(String[] args) {
    System.out.println(md5sum("/init.rc"));
  }

  public static String toHexString(byte[] b) {
    StringBuilder sb = new StringBuilder(b.length * 2);
    for (int i = 0; i < b.length; i++) {
      sb.append(HEX_DIGITS[(b[i] & 0xf0) >>> 4]);
      sb.append(HEX_DIGITS[b[i] & 0x0f]);
    }
    return sb.toString();
  }

  public static String md5sum(String filename) {
    InputStream fis;
    byte[] buffer = new byte[1024];
    int numRead = 0;
    MessageDigest md5;
    try {
      fis = new FileInputStream(filename);
      md5 = MessageDigest.getInstance("MD5");
      while ((numRead = fis.read(buffer)) > 0) {
        md5.update(buffer, 0, numRead);
      }
      fis.close();
      String md5Str = toHexString(md5.digest());
      return TextUtils.isEmpty(md5Str) ? "" : md5Str;
    } catch (Exception e) {
      System.out.println("error");
      return "";
    }
  }

  /**
   * @param str
   * @return
   * @Date: 2013-9-6
   * @Author: lulei
   * @Description: 32位小写MD5
   */
  public static String parseStrToMd5L32(String str) {
    String reStr = null;
    try {
      MessageDigest md5 = null;
      try {
        md5 = MessageDigest.getInstance("MD5");
      } catch (NoSuchAlgorithmException e) {
        e.printStackTrace();
      }
      byte[] bytes = md5.digest(str.getBytes());
      StringBuffer stringBuffer = new StringBuffer();
      for (byte b : bytes) {
        int bt = b & 0xff;
        if (bt < 16) {
          stringBuffer.append(0);
        }
        stringBuffer.append(Integer.toHexString(bt));
      }
      reStr = stringBuffer.toString();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return reStr;
  }

  /**
   * @param str
   * @return
   * @Date: 2013-9-6
   * @Author: lulei
   * @Description: 32位大写MD5
   */
  public static String parseStrToMd5U32(String str) {
    String reStr = parseStrToMd5L32(str);
    if (reStr != null) {
      reStr = reStr.toUpperCase();
    }
    return reStr;
  }

  /**
   * @param str
   * @return
   * @Date: 2013-9-6
   * @Author: lulei
   * @Description: 16位小写MD5
   */
  public static String parseStrToMd5U16(String str) {
    String reStr = parseStrToMd5L32(str);
    if (reStr != null) {
      reStr = reStr.toUpperCase().substring(8, 24);
    }
    return reStr;
  }

  /**
   * @param str
   * @return
   * @Date: 2013-9-6
   * @Author: lulei
   * @Description: 16位大写MD5
   */
  public static String parseStrToMd5L16(String str) {
    String reStr = parseStrToMd5L32(str);
    if (reStr != null) {
      reStr = reStr.substring(8, 24);
    }
    return reStr;
  }
}