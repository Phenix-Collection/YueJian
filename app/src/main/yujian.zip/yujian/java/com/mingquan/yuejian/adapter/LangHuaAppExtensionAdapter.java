package com.mingquan.yuejian.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mingquan.yuejian.R;
import com.mingquan.yuejian.adapter.holder.LangHuaAppRecyclerViewHolder;
import com.mingquan.yuejian.proto.model.LangHuaAppACExtensionBarModel;
import com.mingquan.yuejian.utils.LangHuaAppStringUtil;
import com.mingquan.yuejian.utils.LangHuaAppTLog;
import com.mingquan.yuejian.utils.LangHuaAppUIHelper;

/**
 * Created by Administrator on 2019/3/29
 */

public class LangHuaAppExtensionAdapter extends LangHuaAppBaseRecyclerMutilAdapter<LangHuaAppACExtensionBarModel> {
    public LangHuaAppExtensionAdapter(Context ctx) {
        super(ctx);
    }

    @Override
    public LangHuaAppRecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new LangHuaAppRecyclerViewHolder(
                context,
                LayoutInflater.from(context).inflate(R.layout.lang_hua_app_item_extension, null, false)
        );
    }

    @Override
    public void onBindViewHolder(LangHuaAppRecyclerViewHolder holder, final int position) {
        final LangHuaAppACExtensionBarModel model = list.get(position);
        holder.getTextView(R.id.tv_item_title).setText(model.getName());
        holder.getTextView(R.id.tv_item_content).setText(model.getContent());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (LangHuaAppStringUtil.isEmpty(model.getLinkUrl())) {
                    LangHuaAppTLog.error("url is empty");
                    return;
                }
                LangHuaAppUIHelper.showWebView(context, model.getLinkUrl(), "");
            }
        });
    }
}
