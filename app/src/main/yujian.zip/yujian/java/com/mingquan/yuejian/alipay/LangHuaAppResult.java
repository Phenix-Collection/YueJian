package com.mingquan.yuejian.alipay;

public class LangHuaAppResult {
  String resultStatus;
  String result;
  String memo;

  public LangHuaAppResult(String rawResult) {
    try {
      String[] resultParams = rawResult.split(";");
      for (String resultParam : resultParams) {
        if (resultParam.startsWith("resultStatus")) {
          resultStatus = gatValue(resultParam, "resultStatus");
        }
        if (resultParam.startsWith("result")) {
          result = gatValue(resultParam, "result");
        }
        if (resultParam.startsWith("memo")) {
          memo = gatValue(resultParam, "memo");
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  public String getResultStatus() {
    return this.resultStatus;
  }

  @Override
  public String toString() {
    return "resultStatus={" + resultStatus + "};memo={" + memo + "};result={" + result + "}";
  }

  private String gatValue(String content, String key) {
    String prefix = key + "={";
    return content.substring(content.indexOf(prefix) + prefix.length(), content.lastIndexOf("}"));
  }
}
