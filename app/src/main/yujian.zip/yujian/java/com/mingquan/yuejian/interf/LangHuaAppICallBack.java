package com.mingquan.yuejian.interf;

/**
 * Created by heaney on 2018/3/8.
 */

public interface LangHuaAppICallBack {
    void operate();
}
