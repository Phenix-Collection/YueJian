package com.mingquan.yuejian.hyphenate;

import com.hyphenate.EMMessageListener;
import com.hyphenate.chat.EMMessage;

import java.util.List;

/**
 * 创建者:   Leon
 * 创建时间:  2016/10/20 17:51
 * 描述：    TODO
 */
public class EMMessageListenerAdapter implements EMMessageListener {

    @Override
    public void onMessageReceived(List<EMMessage> list) {

    }

    @Override
    public void onCmdMessageReceived(List<EMMessage> list) {

    }

    @Override
    public void onMessageRead(List<EMMessage> list) {

    }

    @Override
    public void onMessageDelivered(List<EMMessage> list) {

    }

    @Override
    public void onMessageRecalled(List<EMMessage> list) {

    }


    @Override
    public void onMessageChanged(EMMessage emMessage, Object o) {

    }
}
