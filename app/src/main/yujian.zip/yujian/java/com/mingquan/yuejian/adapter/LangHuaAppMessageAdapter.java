package com.mingquan.yuejian.adapter;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.mingquan.yuejian.LangHuaAppAppConfig;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.ui.dialog.LangHuaAppDialogHelper;
import com.mingquan.yuejian.ui.view.LangHuaAppChatImageView;
import com.mingquan.yuejian.utils.LangHuaAppTLog;
import com.mingquan.yuejian.vchat.LangHuaAppLargerImageDialogFragment;
import com.mingquan.yuejian.widget.LangHuaAppAvatarView;
import com.mingquan.yuejian.widget.LangHuaAppPhoneLiveChatRow;
import com.mingquan.yuejian.widget.LangHuaAppPhoneLiveChatRowImage;
import com.mingquan.yuejian.widget.LangHuaAppPhoneLiveChatRowText;
import com.hyphenate.chat.EMImageMessageBody;
import com.hyphenate.chat.EMMessage;

import java.util.ArrayList;
import java.util.List;

/**
 * 私信详情列表适配器
 */
public class LangHuaAppMessageAdapter extends BaseAdapter {
    private List<EMMessage> mChats = new ArrayList<>();
    private LayoutInflater inflate;
    private FragmentActivity context;

    public LangHuaAppMessageAdapter(FragmentActivity context) {
        this.context = context;
        this.inflate = LayoutInflater.from(context);
    }

    public void setChatList(List<EMMessage> mChats) {
        LangHuaAppTLog.debug("setChatList");
        this.mChats = mChats;
        this.notifyDataSetChanged();
    }

    public void addMessage(EMMessage emMessage) {
        LangHuaAppTLog.debug("addMessage");
        this.mChats.add(emMessage);
        this.notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mChats.size();
    }

    @Override
    public Object getItem(int position) {
        return mChats.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final EMMessage e = mChats.get(position);
        LangHuaAppPhoneLiveChatRow view = null;
        switch (e.getType()) {
            case TXT: //文本或礼物
                view = new LangHuaAppPhoneLiveChatRowText(context, e, position, this);
                break;
            case IMAGE: //图片
                view = new LangHuaAppPhoneLiveChatRowImage(context, e, position, this);
                break;
        }
        LangHuaAppAvatarView mUhead = (LangHuaAppAvatarView) view.findViewById(R.id.av_message_head);
        LangHuaAppChatImageView mImage = (LangHuaAppChatImageView) view.findViewById(R.id.iv_message_image);
        //点击头像进入用户详情页
        final String uid = e.getFrom().replace(LangHuaAppAppConfig.IM_ACCOUNT, "");
        mUhead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ("120001".equals(uid)) {
                    LangHuaAppTLog.info("系统消息");
                    return;
                }
                LangHuaAppDialogHelper.showVchatOtherInfoDialogFragment(context.getSupportFragmentManager(), uid);
            }
        });

        if (mImage != null) {
            mImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EMImageMessageBody emImageMessageBody = (EMImageMessageBody) e.getBody();
                    LangHuaAppLargerImageDialogFragment largerImage = new LangHuaAppLargerImageDialogFragment();
                    Bundle bundle = new Bundle();
                    if (e.direct() == EMMessage.Direct.SEND) {
                        LangHuaAppTLog.debug("send image path:%s", emImageMessageBody.getRemoteUrl());
                        bundle.putString("imagePath", emImageMessageBody.getRemoteUrl());
                    } else {
                        LangHuaAppTLog.debug("receive image path:%s", emImageMessageBody.getThumbnailUrl());
                        bundle.putString("imagePath", emImageMessageBody.getThumbnailUrl());
                    }
                    largerImage.setArguments(bundle);
                    largerImage.setStyle(
                            DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
                    largerImage.show(context.getSupportFragmentManager(), "LangHuaAppLargerImageDialogFragment");
                }
            });
        }

        //缓存的view的message很可能不是当前item的，传入当前message和position更新ui
        view.setUpView(e, position);
        return view;
    }
}
