package com.mingquan.yuejian.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.adapter.holder.LangHuaAppRecyclerViewHolder;
import com.mingquan.yuejian.base.LangHuaAppBaseApplication;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserPublicInfoModel;
import com.mingquan.yuejian.ui.view.LangHuaAppMyRatingBar;
import com.mingquan.yuejian.utils.LangHuaAppTDevice;
import com.mingquan.yuejian.utils.LangHuaAppTLog;
import com.mingquan.yuejian.widget.LangHuaAppSlideShowView;
import com.mingquan.yuejian.widget.LangHuaAppStatusTextView;
import com.mingquan.yuejian.xrecyclerview.LangHuaAppLoadingMoreFooter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by administrato on 2017/3/23
 */

public class LangHuaAppIndexChildAdapter extends LangHuaAppBaseRecyclerMutilAdapter<LangHuaAppACUserPublicInfoModel> {

    private final static int TYPE_COMMON = 0;
    private final static int TYPE_FOOTER = 1;
    private final static int TYPE_HEADER = 2;

    private LangHuaAppLoadingMoreFooter mMoreFooter;
    private ArrayList<String> mImageList = new ArrayList<>();
    private ArrayList<String> mUrlList = new ArrayList<>();
    private boolean canVideoChat = false;

    public LangHuaAppLoadingMoreFooter getMoreFooter() {
        return mMoreFooter;
    }

    public LangHuaAppIndexChildAdapter(Context ctx) {
        super(ctx);
        canVideoChat = LangHuaAppAppContext.getInstance().getCanVideoChat();
        mMoreFooter = new LangHuaAppLoadingMoreFooter(context, context.getResources().getColor(R.color.gray));
        mMoreFooter.setLayoutParams(
                new RecyclerView.LayoutParams(
                        RecyclerView.LayoutParams.MATCH_PARENT,
                        RecyclerView.LayoutParams.WRAP_CONTENT));
    }

    @Override
    public LangHuaAppRecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case TYPE_HEADER:
                View headView = LayoutInflater.from(context).inflate(R.layout.lang_hua_app_banner_layout, parent, false);
                headView.setLayoutParams(new LinearLayout.LayoutParams((int) LangHuaAppTDevice.getScreenWidth(), ((int) (LangHuaAppTDevice.getScreenWidth() / 4))));
                return new LangHuaAppRecyclerViewHolder(context, headView);
            case TYPE_COMMON:
                return new LangHuaAppRecyclerViewHolder(
                        context,
                        LayoutInflater.from(context).inflate(R.layout.lang_hua_app_index_child_list_item, parent, false));
            case TYPE_FOOTER:
                return new LangHuaAppRecyclerViewHolder(context, mMoreFooter);
            default:
                return new LangHuaAppRecyclerViewHolder(context, mMoreFooter);
        }
    }

    @Override
    public void onBindViewHolder(LangHuaAppRecyclerViewHolder holder, final int position) {
        switch (getItemViewType(position)) {
            case TYPE_HEADER:
                LangHuaAppTLog.debug("on bind view holder header");
                if (mImageList.size() > 0) {
                    ((LangHuaAppSlideShowView) holder.getView(R.id.banner)).setImageList(mImageList);
                    ((LangHuaAppSlideShowView) holder.getView(R.id.banner)).setUrlList(mUrlList);
                    ((LangHuaAppSlideShowView) holder.getView(R.id.banner)).startPlay();
                }
                break;
            case TYPE_COMMON:
                LangHuaAppTLog.debug("on bind view holder common");
                final int index = mImageList.size() > 0 ? position - 1 : position;
                holder.getView(R.id.ll_coin_time).setVisibility(canVideoChat ? View.VISIBLE : View.GONE);
                holder.getView(R.id.status).setVisibility(canVideoChat ? View.VISIBLE : View.GONE);
                ((LangHuaAppMyRatingBar) holder.getView(R.id.rating_bar)).setStar(list.get(index).getStar());
                LangHuaAppBaseApplication.getImageLoaderUtil().loadImage_glide(
                        context,
                        list.get(index).getAvatarUrl(),
                        holder.getImageView(R.id.image_view));

                holder.getTextView(R.id.nick).setText(list.get(index).getName());

                boolean canVideoChat = false;
                if (LangHuaAppAppContext.getInstance().getPrivateInfoModel() != null) {
                    canVideoChat = LangHuaAppAppContext.getInstance().getPrivateInfoModel().getCanVideoChat();
                }
                holder.getTextView(R.id.sign).setText(canVideoChat ? list.get(index).getSignature() : "");
                holder.getView(R.id.ll_coin_time).setVisibility(canVideoChat ? View.VISIBLE : View.GONE);
                holder.getView(R.id.status).setVisibility(canVideoChat ? View.VISIBLE : View.GONE);
                holder.getTextView(R.id.tv_coin_time).setText(String.valueOf(list.get(index).getPrice()));
                holder.getTextView(R.id.tv_user_id).setText(String.format("ID:%s", list.get(index).getUid()));
                ((LangHuaAppStatusTextView) holder.getView(R.id.status)).setStatus(list.get(index).getStatus(), list.get(index).getStatusTag());
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mClickListener.onItemClick(v, index);
                    }
                });
                break;
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (mImageList.size() > 0) {
            if (position == 0) {
                return TYPE_HEADER;
            } else if (position < list.size()) {
                return TYPE_COMMON;
            } else {
                return TYPE_FOOTER;
            }
        } else {
            if (position < list.size()) {
                return TYPE_COMMON;
            } else {
                return TYPE_FOOTER;
            }
        }
    }

    @Override
    public int getItemCount() {
        return mImageList.size() > 0 ? list.size() + 1 : list.size();
    }

//    mBannerView.setImageList(mRollImageList);
//    mBannerView.setUrlList(mRollUrlList);

    public void setImageList(List<String> imageList) {
        this.mImageList.clear();
        this.mImageList.addAll(imageList);
    }

    public void setUrlList(List<String> urlList) {
        this.mUrlList.clear();
        this.mUrlList.addAll(urlList);
    }

}
