package com.mingquan.yuejian.vchat;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.media.MediaMetadataRetriever;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.auth.LangHuaAppGridVideoAdapter;
import com.mingquan.yuejian.base.LangHuaAppFullScreenModeActivity;
import com.mingquan.yuejian.interf.LangHuaAppINomalDialog;
import com.mingquan.yuejian.proto.LangHuaAppApiProtoHelper;
import com.mingquan.yuejian.proto.model.LangHuaAppACVideoInfoModel;
import com.mingquan.yuejian.ui.dialog.LangHuaAppEditableActionSheetDialog;
import com.mingquan.yuejian.utils.LangHuaAppDialogHelp;
import com.mingquan.yuejian.utils.LangHuaAppStringUtil;
import com.mingquan.yuejian.utils.LangHuaAppTLog;
import com.mingquan.yuejian.utils.LangHuaAppUIHelper;
import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.compress.Luban;
import com.luck.picture.lib.config.PictureConfig;
import com.luck.picture.lib.config.PictureMimeType;
import com.luck.picture.lib.entity.LocalMedia;
import com.qiniu.android.http.ResponseInfo;
import com.qiniu.android.storage.UpCompletionHandler;
import com.qiniu.android.storage.UpProgressHandler;
import com.qiniu.android.storage.UploadOptions;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LangHuaAppUploadVideoActivity extends LangHuaAppFullScreenModeActivity {

    @BindView(R.id.title_layout)
    LangHuaAppXTemplateTitle titleLayout;
    @BindView(R.id.rcv_video)
    RecyclerView rcvVideo;
    private Activity mContext;
    private String videoUploadToken;
    private LangHuaAppGridVideoAdapter videoAdapter;
    private ArrayList<LangHuaAppACVideoInfoModel> videoList = new ArrayList<>();
    private LangHuaAppOneGoGridLayoutManager mLayoutManager;
    private int mlastId = 0;
    private Toast toast;
    private String path;
    String videoKey = "";
    String imageKey = "";
    private ProgressDialog waitDialog;
    private boolean isVisible = false;
    private int price;
    public static final int SET_ADD_VIDEO_PRICE = 100;
    public static final int SET_VIDEO_PRICE = 101;
    private boolean canVideoChat = false; // 是否能连麦

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lang_hua_app_activity_upload_video);
        ButterKnife.bind(this);
        mContext = this;
        canVideoChat = LangHuaAppAppContext.getInstance().getCanVideoChat();
        titleLayout.setLeftBtnListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        getVideoUploadToken();
        toast = Toast.makeText(LangHuaAppUploadVideoActivity.this, "", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        initData();
    }

    private void getVideoUploadToken() {
        LangHuaAppApiProtoHelper.sendACGetQiniuUploadTokenReq(
                this,
                LangHuaAppAppContext.getInstance().getLoginUid(),
                LangHuaAppAppContext.getInstance().getToken(),
                LangHuaAppApiProtoHelper.UPLOAD_FILE_VIDEO,
                new LangHuaAppApiProtoHelper.ACGetQiniuUploadTokenReqCallback() {
                    @Override
                    public void onError(int errCode, String errMessage) {

                    }

                    @Override
                    public void onResponse(String uploadToken) {
                        videoUploadToken = uploadToken;
                    }
                }
        );
    }

    private void initData() {
        videoAdapter = new LangHuaAppGridVideoAdapter(this);
        videoAdapter.setList(videoList);
        videoAdapter.setOnItemClickListener(new LangHuaAppGridVideoAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(final int position, View v) {

                if (position == 0) { // 打开相册
                    if (!canVideoChat) {
                        LangHuaAppUIHelper.showSetVideoPriceActivity(mContext, -1);
                        return;
                    }
                    LangHuaAppDialogHelp.showDialog(mContext, "是否要设定视频价格？", new LangHuaAppINomalDialog() {
                        @Override
                        public void cancelDialog(View v, Dialog d) {
                            showPhotoAlbum();
                            price = 0;
                            d.dismiss();
                        }

                        @Override
                        public void determineDialog(View v, Dialog d) {
                            LangHuaAppUIHelper.showSetVideoPriceActivity(mContext, -1);
                            d.dismiss();
                        }
                    });
                } else {
                    showVideoMenu(position - 1);
                }
            }
        });
        mLayoutManager = new LangHuaAppOneGoGridLayoutManager(mContext, 2);
        rcvVideo.addItemDecoration(new RecyclerView.ItemDecoration() {
            @Override
            public void getItemOffsets(Rect outRect, int itemPosition, RecyclerView parent) {
                if (itemPosition % 2 == 0) {
                    outRect.right = 2;
                    outRect.bottom = 4;
                } else {
                    outRect.left = 2;
                    outRect.bottom = 4;
                }
            }
        });
        rcvVideo.setLayoutManager(mLayoutManager);
        rcvVideo.setAdapter(videoAdapter);
        requestBroadcasterVideoList();
    }

    private void requestBroadcasterVideoList() {
        LangHuaAppApiProtoHelper.sendACGetBroadcasterVideoListReq(
                mContext,
                LangHuaAppAppContext.getInstance().getLoginUid(),
                LangHuaAppAppContext.getInstance().getToken(),
                LangHuaAppAppContext.getInstance().getLoginUid(),
                20,
                mlastId,
                new LangHuaAppApiProtoHelper.ACGetBroadcasterVideoListReqCallback() {
                    @Override
                    public void onError(int errCode, String errMessage) {

                    }

                    @Override
                    public void onResponse(ArrayList<LangHuaAppACVideoInfoModel> videos, int nextOffset) {
//                        mlastId = nextOffset;
                        videoList.clear();
                        videoList.addAll(videos);
                        videoAdapter.notifyDataSetChanged();
                    }
                }
        );
    }

    private void showPhotoAlbum() {
        PictureSelector.create(mContext)
                .openGallery(PictureMimeType.ofVideo())// 全部.PictureMimeType.ofAll()、图片.ofImage()、视频.ofVideo()、音频.ofAudio()
                .imageSpanCount(4)// 每行显示个数
                .selectionMode(PictureConfig.SINGLE)// 多选 or 单选PictureConfig.MULTIPLE : PictureConfig.SINGLE
                .previewImage(true)// 是否可预览图片
                .compressGrade(Luban.THIRD_GEAR)// luban压缩档次，默认3档 Luban.FIRST_GEAR、Luban.CUSTOM_GEAR
                .isCamera(true)// 是否显示拍照按钮
                .isZoomAnim(true)// 图片列表点击 缩放效果 默认true
                .enableCrop(true)// 是否裁剪
                .compress(true)// 是否压缩
                .compressMode(PictureConfig.LUBAN_COMPRESS_MODE)//系统自带 or 鲁班压缩 PictureConfig.SYSTEM_COMPRESS_MODE or LUBAN_COMPRESS_MODE
                .glideOverride(160, 160)// glide 加载宽高，越小图片列表越流畅，但会影响列表图片浏览的清晰度
                .withAspectRatio(1, 1)// 裁剪比例 如16:9 3:2 3:4 1:1 可自定义
                .rotateEnabled(false) // 裁剪是否可旋转图片
                .recordVideoSecond(60)//录制视频秒数 默认60s
                .forResult(PictureConfig.CHOOSE_REQUEST);//结果回调onActivityResult code
    }

    /**
     * 播放，删除，设定价格的菜单
     *
     * @param position
     */
    private void showVideoMenu(final int position) {
        final LangHuaAppEditableActionSheetDialog mDialog = new LangHuaAppEditableActionSheetDialog(this).builder();
        TextView play = new TextView(this);
        TextView price = new TextView(this);
        TextView delete = new TextView(this);
        mDialog.addSheetItem(play, "播放视频", LangHuaAppEditableActionSheetDialog.SheetItemColor.Blue,
                new LangHuaAppEditableActionSheetDialog.OnSheetItemClickListener() {
                    @Override
                    public void onClick(int which) {
                        LangHuaAppUIHelper.showShortVideoPlayerActivity(LangHuaAppUploadVideoActivity.this, videoList, position);
                        mDialog.cancel();
                    }
                });
        if (canVideoChat) {
            mDialog.addSheetItem(price, "设定价格", LangHuaAppEditableActionSheetDialog.SheetItemColor.Blue,
                    new LangHuaAppEditableActionSheetDialog.OnSheetItemClickListener() {
                        @Override
                        public void onClick(int which) {
                            LangHuaAppUIHelper.showSetVideoPriceActivity(mContext, videoList.get(position).getVideoId());
                            mDialog.cancel();
                        }
                    });
        }

        mDialog.addSheetItem(delete, "删除视频", LangHuaAppEditableActionSheetDialog.SheetItemColor.Blue,
                new LangHuaAppEditableActionSheetDialog.OnSheetItemClickListener() {
                    @Override
                    public void onClick(int which) {
                        LangHuaAppApiProtoHelper.sendACDeleteVideoReq(
                                LangHuaAppUploadVideoActivity.this,
                                LangHuaAppAppContext.getInstance().getLoginUid(),
                                LangHuaAppAppContext.getInstance().getToken(),
                                videoList.get(position).getVideoId(),
                                new LangHuaAppApiProtoHelper.ACDeleteVideoReqCallback() {
                                    @Override
                                    public void onError(int errCode, String errMessage) {
                                        toast.setText(errMessage);
                                        toast.show();
                                    }

                                    @Override
                                    public void onResponse() {
                                        toast.setText("删除成功！");
                                        toast.show();
                                        videoList.remove(position);
                                        videoAdapter.notifyDataSetChanged();
                                    }
                                }
                        );
                        mDialog.cancel();
                    }
                });
        mDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        LangHuaAppTLog.debug("requestCode:%s, resultCode:%s", requestCode, resultCode);
        switch (resultCode) {
            case RESULT_OK:
                if (requestCode == PictureConfig.CHOOSE_REQUEST) {
                    // 图片选择结果回调
                    List<LocalMedia> videos = PictureSelector.obtainMultipleResult(data);
                    path = videos.get(0).getPath();
                    LangHuaAppAppContext.getInstance().getUploadManager().put(
                            path,
                            LangHuaAppAppContext.getInstance().getLoginUid() + System.currentTimeMillis(),
                            videoUploadToken,
                            videoCompletionHandler,
                            uploadOptions);
                }
                break;
            case SET_ADD_VIDEO_PRICE:
                price = data.getIntExtra("SET_ADD_VIDEO_PRICE", -1);
                showPhotoAlbum();
                break;
            case SET_VIDEO_PRICE:
                requestBroadcasterVideoList();
                break;
        }
    }

    private UpCompletionHandler videoCompletionHandler = new UpCompletionHandler() {
        @Override
        public void complete(String key, ResponseInfo info, JSONObject response) {
            try {
                if (response == null) {
                    LangHuaAppTLog.error("upload video response == null!!");
                    return;
                }
                videoKey = (String) response.get("key");
                if (LangHuaAppStringUtil.isEmpty(videoKey)) {
                    LangHuaAppTLog.error("upload video key is empty!!");
                    return;
                }

                if (info != null && info.isOK()) {
                    toast.setText("video upload success!");
                    toast.show();

                    try {
                        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                        retriever.setDataSource(path);
                        Bitmap bitmap = retriever.getFrameAtTime();
                        FileOutputStream outStream = null;
                        final String localThumb = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + System.currentTimeMillis() + ".jpg";
                        outStream = new FileOutputStream(new File(localThumb));
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 30, outStream);
                        outStream.close();
                        retriever.release();
                        LangHuaAppAppContext.getInstance().getUploadManager().put(
                                localThumb,
                                LangHuaAppAppContext.getInstance().getLoginUid() + "_" + System.currentTimeMillis(),
                                videoUploadToken,
                                imageCompletionHandler,
                                uploadOptions);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    toast.setText("video upload failure!");
                    toast.show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private UpCompletionHandler imageCompletionHandler = new UpCompletionHandler() {
        @Override
        public void complete(String key, ResponseInfo info, JSONObject response) {
            try {
                if (response == null) {
                    LangHuaAppTLog.error("upload image response == null!!");
                    return;
                }
                imageKey = (String) response.get("key");
                if (LangHuaAppStringUtil.isEmpty(imageKey)) {
                    LangHuaAppTLog.error("upload image key is empty!!");
                    return;
                }
                if (info != null && info.isOK()) {
                    hideWaitDialog();
                    toast.setText("短视频上传成功!");
                    toast.show();


                    LangHuaAppApiProtoHelper.sendACUploadVideoReq(
                            mContext,
                            LangHuaAppAppContext.getInstance().getLoginUid(),
                            LangHuaAppAppContext.getInstance().getToken(),
                            videoKey,
                            imageKey,
                            price, new LangHuaAppApiProtoHelper.ACUploadVideoReqCallback() {
                                @Override
                                public void onError(int errCode, String errMessage) {
                                    toast.setText(errMessage);
                                    toast.show();
                                }

                                @Override
                                public void onResponse(LangHuaAppACVideoInfoModel video) {
                                    videoList.add(video);
                                    videoAdapter.notifyDataSetChanged();
                                }
                            });

                } else {
                    hideWaitDialog();
                    toast.setText("image upload failure!");
                    toast.show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private UploadOptions uploadOptions = new UploadOptions(
            null,
            null,
            false,
            new UpProgressHandler() {
                @Override
                public void progress(String key, double percent) {
                    LangHuaAppTLog.debug("%s::::::::%s", key, percent);
                    showWaitDialog();
                }
            }, null);

    private void showWaitDialog() {
        if (isVisible) {
            return;
        }
        if (waitDialog == null) {
            waitDialog = LangHuaAppDialogHelp.getWaitDialog(this, "正在上传，请稍后。。。");
            waitDialog.setCanceledOnTouchOutside(false);
            isVisible = true;
            waitDialog.show();
        }
    }

    private void hideWaitDialog() {
        if (waitDialog != null) {
            waitDialog.dismiss();
            waitDialog = null;
            isVisible = false;
        }
    }
}
