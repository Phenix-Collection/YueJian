package com.mingquan.yuejian.huawei.push;

import android.os.Handler;
import android.os.Looper;

import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.support.api.push.HuaweiPush;
import com.mingquan.yuejian.huawei.LangHuaAppHMSAgent;
import com.mingquan.yuejian.huawei.common.LangHuaAppApiClientMgr;
import com.mingquan.yuejian.huawei.common.LangHuaAppBaseApiAgent;
import com.mingquan.yuejian.huawei.common.LangHuaAppCallbackCodeRunnable;
import com.mingquan.yuejian.huawei.common.LangHuaAppHMSAgentLog;
import com.mingquan.yuejian.huawei.common.LangHuaAppStrUtils;
import com.mingquan.yuejian.huawei.common.LangHuaAppThreadUtil;
import com.mingquan.yuejian.huawei.push.handler.LangHuaAppGetPushStateHandler;

/**
 * 获取push状态的接口。
 */
public class LangHuaAppGetPushStateApi extends LangHuaAppBaseApiAgent {

    /**
     * 调用接口回调
     */
    private LangHuaAppGetPushStateHandler handler;

    /**
     * HuaweiApiClient 连接结果回调
     *
     * @param rst    结果码
     * @param client HuaweiApiClient 实例
     */
    @Override
    public void onConnect(final int rst, final HuaweiApiClient client) {
        //需要在子线程中执行获取push状态的操作
        LangHuaAppThreadUtil.INST.excute(new Runnable() {
            @Override
            public void run() {
                if (client == null || !LangHuaAppApiClientMgr.INST.isConnect(client)) {
                    LangHuaAppHMSAgentLog.e("client not connted");
                    onGetPushStateResult(rst);
                } else {
                    HuaweiPush.HuaweiPushApi.getPushState(client);
                    onGetPushStateResult(LangHuaAppHMSAgent.AgentResultCode.HMSAGENT_SUCCESS);
                }
            }
        });
    }

    void onGetPushStateResult(int rstCode) {
        LangHuaAppHMSAgentLog.i("getPushState:callback=" + LangHuaAppStrUtils.objDesc(handler) +" retCode=" + rstCode);
        if (handler != null) {
            new Handler(Looper.getMainLooper()).post(new LangHuaAppCallbackCodeRunnable(handler, rstCode));
            handler = null;
        }
    }

    /**
     * 获取push状态，push状态的回调通过广播发送。
     * 要监听的广播，请参见HMS-SDK开发准备中PushReceiver的注册
     */
    public void getPushState(LangHuaAppGetPushStateHandler handler) {
        LangHuaAppHMSAgentLog.i("getPushState:handler=" + LangHuaAppStrUtils.objDesc(handler));
        this.handler = handler;
        connect();
    }
}
