package com.mingquan.yuejian.utils.network;

/**
 * 网络状态相关 来自github
 */

public enum LangHuaAppNetType {
  NO_NET, //没有网络
  NET_WIFI, // wifi 网络
  NET_3G_4G //移动网络  3G 4G
}
