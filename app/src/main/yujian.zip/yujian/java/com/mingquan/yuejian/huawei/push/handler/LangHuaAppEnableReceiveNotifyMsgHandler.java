package com.mingquan.yuejian.huawei.push.handler;

import com.mingquan.yuejian.huawei.common.LangHuaAppICallbackCode;

/**
 * enableReceiveNotifyMsg 回调
 */
public interface LangHuaAppEnableReceiveNotifyMsgHandler extends LangHuaAppICallbackCode {
}
