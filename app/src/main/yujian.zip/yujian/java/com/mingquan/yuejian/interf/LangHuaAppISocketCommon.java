package com.mingquan.yuejian.interf;

public interface LangHuaAppISocketCommon {
    String KEY_PROTO = "proto_id", BROADCAST = "broadcastingListen", METHOD_KEY = "_method_",
            EVENT_NAME = "broadcast", KEY_EMIT_CHANNEL_CHAT = "channel.chat",
            KEY_EMIT_ADMIN = "channel.admin", KEY_DATA = "data",
            KEY_MSG = "msg", VALUE_SEND_GIFT_PROTO = "cs.sendGift";
}
