package com.mingquan.yuejian.model;

import com.mingquan.yuejian.proto.model.LangHuaAppACUserTagMetaDataModel;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/9/29
 */

public class LangHuaAppUserTagAndCountModel implements Serializable {
    private LangHuaAppACUserTagMetaDataModel metaDataModel;
    private int count;

    public LangHuaAppACUserTagMetaDataModel getMetaDataModel() {
        return metaDataModel;
    }

    public void setMetaDataModel(LangHuaAppACUserTagMetaDataModel metaDataModel) {
        this.metaDataModel = metaDataModel;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
