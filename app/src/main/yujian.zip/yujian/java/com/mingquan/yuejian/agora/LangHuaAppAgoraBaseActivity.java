package com.mingquan.yuejian.agora;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.mingquan.yuejian.LangHuaAppAppContext;
import io.agora.rtc.RtcEngine;

public abstract class LangHuaAppAgoraBaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((LangHuaAppAppContext) getApplication()).initWorkerThread();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        deInitUIandEvent();
    }

    protected abstract void initUIandEvent();

    protected abstract void deInitUIandEvent();

    protected RtcEngine rtcEngine() {
        return ((LangHuaAppAppContext) getApplication()).getWorkerThread().getRtcEngine();
    }

    protected final LangHuaAppWorkerThread worker() {
        return ((LangHuaAppAppContext) getApplication()).getWorkerThread();
    }

    protected final LangHuaAppEngineConfig config() {
        return ((LangHuaAppAppContext) getApplication()).getWorkerThread().getEngineConfig();
    }

    protected final LangHuaAppMyEngineEventHandler event() {
        return ((LangHuaAppAppContext) getApplication()).getWorkerThread().eventHandler();
    }
}
