package com.mingquan.yuejian.huawei.push.handler;

import com.mingquan.yuejian.huawei.common.LangHuaAppICallbackCode;

/**
 * queryAgreement 回调
 */
public interface LangHuaAppQueryAgreementHandler extends LangHuaAppICallbackCode {
}
