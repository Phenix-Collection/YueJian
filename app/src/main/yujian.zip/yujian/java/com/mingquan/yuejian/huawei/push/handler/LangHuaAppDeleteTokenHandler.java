package com.mingquan.yuejian.huawei.push.handler;

import com.mingquan.yuejian.huawei.common.LangHuaAppICallbackCode;

/**
 * deleteToken 回调
 */
public interface LangHuaAppDeleteTokenHandler extends LangHuaAppICallbackCode {
}
