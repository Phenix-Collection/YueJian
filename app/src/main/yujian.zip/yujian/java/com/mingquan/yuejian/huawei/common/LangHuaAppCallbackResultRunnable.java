package com.mingquan.yuejian.huawei.common;

/**
 * 回调线程
 */
public class LangHuaAppCallbackResultRunnable<R> implements Runnable {

    private LangHuaAppICallbackResult<R> handlerInner;
    private int rtnCodeInner;
    private R resultInner;

    public LangHuaAppCallbackResultRunnable(LangHuaAppICallbackResult<R> handler, int rtnCode, R payInfo) {
        handlerInner = handler;
        rtnCodeInner = rtnCode;
        resultInner = payInfo;
    }

    @Override
    public void run() {
        if (handlerInner != null) {
            handlerInner.onResult(rtnCodeInner, resultInner);
        }
    }
}