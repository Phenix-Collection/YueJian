package com.mingquan.yuejian.vchat;

import android.app.Dialog;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.base.LangHuaAppFullScreenModeActivity;
import com.mingquan.yuejian.interf.LangHuaAppINomalDialog;
import com.mingquan.yuejian.proto.LangHuaAppApiProtoHelper;
import com.mingquan.yuejian.proto.model.LangHuaAppACVideoInfoModel;
import com.mingquan.yuejian.ui.dialog.LangHuaAppDialogHelper;
import com.mingquan.yuejian.utils.LangHuaAppDialogHelp;
import com.mingquan.yuejian.utils.LangHuaAppDisplayUtils;
import com.mingquan.yuejian.utils.LangHuaAppTLog;
import com.mingquan.yuejian.utils.LangHuaAppUIHelper;
import com.mingquan.yuejian.utils.LangHuaAppUiUtils;
import com.mingquan.yuejian.utils.LangHuaAppUtils;
import com.mingquan.yuejian.widget.LangHuaAppAvatarView;
import com.mingquan.yuejian.widget.LangHuaAppStatusTextView;
import com.ksyun.media.player.IMediaPlayer;
import com.ksyun.media.player.KSYMediaPlayer;
import com.ksyun.media.player.KSYTextureView;

import java.io.IOException;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class LangHuaAppVChatShortVideoPlayActivity extends LangHuaAppFullScreenModeActivity implements View.OnClickListener {

    @BindView(R.id.root_view)
    RelativeLayout rootView;
    @BindView(R.id.video_view)
    KSYTextureView videoView;
    @BindView(R.id.iv_mask)
    ImageView ivMask;
    @BindView(R.id.iv_play)
    ImageView ivPlay;
    @BindView(R.id.iv_back)
    ImageView ivBack;
    @BindView(R.id.top_bar)
    RelativeLayout topBar;
    @BindView(R.id.tv_name)
    TextView tvName;
    @BindView(R.id.tv_status)
    LangHuaAppStatusTextView tvStatus;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_to_video)
    TextView tvToVideo;
    @BindView(R.id.av_avatar)
    LangHuaAppAvatarView avAvatar;
    @BindView(R.id.iv_heart)
    ImageView ivHeart;
    @BindView(R.id.tv_video_heart_num)
    TextView tvVideoHeartNum;
    @BindView(R.id.iv_lock)
    ImageView ivLock;
    @BindView(R.id.iv_follow)
    ImageView ivFollow;
    @BindView(R.id.ll_name)
    RelativeLayout llName;
    @BindView(R.id.tv_looker)
    TextView tvLooker;
    @BindView(R.id.tv_share)
    TextView tvShare;
    @BindView(R.id.tv_send_gift)
    TextView tvSendGift;

    private LangHuaAppACVideoInfoModel videoInfoModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lang_hua_app_activity_short_video_play);
        ButterKnife.bind(this);

        videoInfoModel = (LangHuaAppACVideoInfoModel) getIntent().getSerializableExtra("videoInfo");
        initView();
        initData();
        initEvents();
        initPlayer();
    }

    private void initView() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            topBar.setPadding(0,
                    LangHuaAppDisplayUtils.getStatusBarHeight1(getApplicationContext()), 0, 0);
        }

        mToast = Toast.makeText(LangHuaAppVChatShortVideoPlayActivity.this, "", Toast.LENGTH_SHORT);
        mToast.setGravity(Gravity.CENTER, 0, 0);
    }

    private void initData() {

        tvName.setText(videoInfoModel.getBroadcaster().getName());
        tvStatus.setStatus(videoInfoModel.getBroadcaster().getStatus(), videoInfoModel.getBroadcaster().getStatusTag());
        avAvatar.setAvatarUrl(videoInfoModel.getBroadcaster().getAvatarUrl());
        ivHeart.setBackgroundResource(videoInfoModel.getIsFollowing() ? R.drawable.lang_hua_app_icon_02006 : R.drawable.lang_hua_app_icon_02007);
        tvVideoHeartNum.setText("" + videoInfoModel.getFollowerCount());
        LangHuaAppUiUtils.setVisibility(ivLock, videoInfoModel.getHasLocked() ? View.VISIBLE : View.GONE);
        LangHuaAppUiUtils.setVisibility(ivMask, videoInfoModel.getHasLocked() ? View.VISIBLE : View.GONE);
        LangHuaAppUiUtils.setVisibility(ivPlay, videoInfoModel.getHasLocked() ? View.VISIBLE : View.GONE);
    }

    private void initEvents() {
        /*ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (videoView.isPlaying()) {
                    videoView.pause();
                    LangHuaAppUiUtils.setVisibility(ivPlay, View.VISIBLE);
                } else {
                    videoView.start();
                    LangHuaAppUiUtils.setVisibility(ivPlay, View.GONE);
                }
            }
        });
        avAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LangHuaAppDialogHelper.showVchatOtherInfoDialogFragment(getSupportFragmentManager(), videoInfoModel.getBroadcaster().getUid());
            }
        });

        ivHeart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ivHeart.setClickable(false);
                followVideo();
            }
        });
        ivMask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Integer.parseInt(LangHuaAppAppContext.getInstance().getProperty("user.coin")) < videoInfoModel.getPrice()) {//跳转充值页面

                } else {
                    LangHuaAppApiProtoHelper.sendACBuyVideoReq(LangHuaAppVChatShortVideoPlayActivity.this,
                            LangHuaAppAppContext.getInstance().getLoginUid(),
                            LangHuaAppAppContext.getInstance().getToken(),
                            videoInfoModel.getVideoId(),
                            new LangHuaAppApiProtoHelper.ACBuyVideoReqCallback() {
                                @Override
                                public void onError(int errCode, String errMessage) {
                                    LangHuaAppTLog.error("购买视频失败：errCode:%s,errMessage:%s", errCode, errMessage);
                                }

                                @Override
                                public void onResponse() {
                                    LangHuaAppUiUtils.setVisibility(ivMask, View.GONE);
                                    LangHuaAppUiUtils.setVisibility(ivPlay, View.GONE);
                                    LangHuaAppUiUtils.setVisibility(ivLock, View.GONE);
                                }
                            });
                }
            }
        });

        tvToVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LangHuaAppUIHelper.showVideoChatActivity(LangHuaAppVChatShortVideoPlayActivity.this, videoInfoModel.getBroadcaster(), true, "");
            }
        });*/
    }

    @OnClick({R.id.iv_back, R.id.root_view, R.id.av_avatar, R.id.iv_heart, R.id.iv_mask, R.id.tv_to_video, R.id.iv_follow})
    @Override
    public void onClick(View v) {
        if (LangHuaAppUtils.isFastClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.iv_back: // 关闭当前页面
                finish();
                break;
            case R.id.root_view: // 播放或暂停
                if (videoView.isPlaying()) {
                    videoView.pause();
                    LangHuaAppUiUtils.setVisibility(ivPlay, View.VISIBLE);
                } else {
                    videoView.start();
                    LangHuaAppUiUtils.setVisibility(ivPlay, View.GONE);
                }
                break;
            case R.id.av_avatar: // 跳转用户详情页面
                LangHuaAppDialogHelper.showVchatOtherInfoDialogFragment(getSupportFragmentManager(), videoInfoModel.getBroadcaster().getUid());
                break;
            case R.id.iv_heart: // 关注短视频
                followVideo();
                break;
            case R.id.iv_mask: // 购买短视频
                if (Integer.parseInt(LangHuaAppAppContext.getInstance().getProperty("user.coin")) < videoInfoModel.getPrice()) {//跳转充值页面

                } else {
                    LangHuaAppApiProtoHelper.sendACBuyVideoReq(LangHuaAppVChatShortVideoPlayActivity.this,
                            LangHuaAppAppContext.getInstance().getLoginUid(),
                            LangHuaAppAppContext.getInstance().getToken(),
                            videoInfoModel.getVideoId(),
                            new LangHuaAppApiProtoHelper.ACBuyVideoReqCallback() {
                                @Override
                                public void onError(int errCode, String errMessage) {
                                    LangHuaAppTLog.error("购买视频失败：errcode:%s,errMessage:%s", errCode, errMessage);
                                }

                                @Override
                                public void onResponse() {
                                    LangHuaAppUiUtils.setVisibility(ivMask, View.GONE);
                                    LangHuaAppUiUtils.setVisibility(ivPlay, View.GONE);
                                    LangHuaAppUiUtils.setVisibility(ivLock, View.GONE);
                                }
                            });
                }
                break;
            case R.id.tv_to_video:
                LangHuaAppUIHelper.showVideoChatActivity(LangHuaAppVChatShortVideoPlayActivity.this, videoInfoModel.getBroadcaster(), "");
                break;
            case R.id.iv_follow:
                LangHuaAppApiProtoHelper.sendACFollowReq(
                        this,
                        LangHuaAppAppContext.getInstance().getLoginUid(),
                        LangHuaAppAppContext.getInstance().getToken(),
                        videoInfoModel.getBroadcaster().getUid(),
                        new LangHuaAppApiProtoHelper.ACFollowReqCallback() {
                            @Override
                            public void onError(int errCode, String errMessage) {

                            }

                            @Override
                            public void onResponse() {
                                LangHuaAppUiUtils.setVisibility(ivFollow, View.GONE);
                            }
                        }
                );
                break;
        }
    }

    /**
     * （取消）关注视频
     */
    private void followVideo() {
        ivHeart.setClickable(false);
        if (videoInfoModel.getIsFollowing()) { // 已经关注，取消关注视频
            LangHuaAppApiProtoHelper.sendACUnfollowVideoReq(this,
                    LangHuaAppAppContext.getInstance().getLoginUid(),
                    LangHuaAppAppContext.getInstance().getToken(),
                    videoInfoModel.getVideoId(),
                    new LangHuaAppApiProtoHelper.ACUnfollowVideoReqCallback() {
                        @Override
                        public void onError(int errCode, String errMessage) {
                            ivHeart.setClickable(true);
                        }

                        @Override
                        public void onResponse() {
                            mToast.setText("取消成功");
                            mToast.show();
                            videoInfoModel.setIsFollowing(false);
                            videoInfoModel.setFollowerCount(videoInfoModel.getFollowerCount() - 1);
                            ivHeart.setClickable(true);
                            ivHeart.setBackgroundResource(R.drawable.lang_hua_app_icon_02007);
                            tvVideoHeartNum.setText("" + (videoInfoModel.getFollowerCount()));
                        }
                    });
        } else { // 未关注，关注视频
            LangHuaAppApiProtoHelper.sendACFollowVideoReq(this,
                    LangHuaAppAppContext.getInstance().getLoginUid(),
                    LangHuaAppAppContext.getInstance().getToken(),
                    videoInfoModel.getVideoId(),
                    new LangHuaAppApiProtoHelper.ACFollowVideoReqCallback() {
                        @Override
                        public void onError(int errCode, String errMessage) {
                            ivHeart.setClickable(true);
                        }

                        @Override
                        public void onResponse() {
                            mToast.setText("点赞成功");
                            mToast.show();
//                            Toast.makeText(LangHuaAppVChatShortVideoPlayActivity.this,"点赞成功",Toast.LENGTH_SHORT).setGravity(Gravity.CENTER,0,0);
                            videoInfoModel.setIsFollowing(true);
                            videoInfoModel.setFollowerCount(videoInfoModel.getFollowerCount() + 1);
                            ivHeart.setClickable(true);
                            ivHeart.setBackgroundResource(R.drawable.lang_hua_app_icon_02006);
                            tvVideoHeartNum.setText("" + (videoInfoModel.getFollowerCount()));
                        }
                    });
        }
    }

    Toast mToast;

    @Override
    protected void onRestart() {
        super.onRestart();
        if (videoView != null) {
            videoView.runInForeground();
            videoView.start();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (videoView != null) {
            videoView.runInBackground(true);
            videoView.pause();
        }
    }

    /**
     * 初始化播放器
     */
    private void initPlayer() {
        this.setVolumeControlStream(AudioManager.STREAM_MUSIC);
        try {
            videoView.setVideoScalingMode(KSYMediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
            videoView.setKeepScreenOn(true);
            videoView.setOnBufferingUpdateListener(mOnBufferingUpdateListener);
            videoView.setOnCompletionListener(mOnCompletionListener);
            videoView.setOnPreparedListener(mOnPreparedListener);
            videoView.setOnInfoListener(mOnInfoListener);
            videoView.setOnVideoSizeChangedListener(mOnVideoSizeChangeListener);
            videoView.setOnErrorListener(mOnErrorListener);
            videoView.setOnSeekCompleteListener(mOnSeekCompletedListener);
            videoView.setOnMessageListener(mOnMessageListener);
            videoView.setScreenOnWhilePlaying(true);
            videoView.setTimeout(5, 30);
            videoView.setDecodeMode(KSYMediaPlayer.KSYDecodeMode.KSY_DECODE_MODE_AUTO);
            videoView.setBufferTimeMax(2);
            videoView.setBufferSize(15);
            videoView.setDataSource(videoInfoModel.getVideoUrl());


            if (videoInfoModel.getHasLocked()) {
                LangHuaAppTLog.debug("需要付费才能播放");
                LangHuaAppDialogHelp.showDialog(LangHuaAppVChatShortVideoPlayActivity.this, "钻石不足，是否立即充值", new LangHuaAppINomalDialog() {
                    @Override
                    public void cancelDialog(View v, Dialog d) {
                        d.dismiss();
                    }

                    @Override
                    public void determineDialog(View v, Dialog d) {
                        d.dismiss();
                    }
                });
            } else {
                videoView.prepareAsync();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private IMediaPlayer.OnBufferingUpdateListener mOnBufferingUpdateListener = new IMediaPlayer.OnBufferingUpdateListener() {
        @Override
        public void onBufferingUpdate(IMediaPlayer mp, int percent) {
            if (videoView != null) {

            }
        }
    };

    private IMediaPlayer.OnPreparedListener mOnPreparedListener = new IMediaPlayer.OnPreparedListener() {
        @Override
        public void onPrepared(IMediaPlayer mp) {
            /*if (videoInfoModel.getHasLocked()) {
                LangHuaAppTLog.debug("需要付费才能播放");
                LangHuaAppDialogHelp.showConfirmDialog(getLayoutInflater(), LangHuaAppVChatShortVideoPlayActivity.this, "钻石不足，是否立即充值", new LangHuaAppINomalDialog() {
                    @Override
                    public void cancelDialog(View v, Dialog d) {
                        d.dismiss();
                    }

                    @Override
                    public void determineDialog(View v, Dialog d) {
                        d.dismiss();
                        // TODO: 2018/9/10 跳转充值页面
                    }
                });
                return;
            }
            // start player
            videoView.setVideoScalingMode(KSYMediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
            videoView.start();*/
        }
    };

    private IMediaPlayer.OnVideoSizeChangedListener mOnVideoSizeChangeListener = new IMediaPlayer.OnVideoSizeChangedListener() {
        @Override
        public void onVideoSizeChanged(IMediaPlayer mp, int width, int height, int sarNum, int sarDen) {
        }
    };

    private IMediaPlayer.OnSeekCompleteListener mOnSeekCompletedListener = new IMediaPlayer.OnSeekCompleteListener() {
        @Override
        public void onSeekComplete(IMediaPlayer mp) {
        }
    };

    private IMediaPlayer.OnCompletionListener mOnCompletionListener = new IMediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(IMediaPlayer mp) {
            videoView.reload(videoInfoModel.getVideoUrl(), false, KSYMediaPlayer.KSYReloadMode.KSY_RELOAD_MODE_FAST);
        }
    };

    private IMediaPlayer.OnErrorListener mOnErrorListener = new IMediaPlayer.OnErrorListener() {
        @Override
        public boolean onError(IMediaPlayer mp, int what, int extra) {
            LangHuaAppTLog.error("OnErrorListener, Error:" + what + ",extra:" + extra);
            //      videoPlayEnd();
            return false;
        }
    };

    public IMediaPlayer.OnInfoListener mOnInfoListener = new IMediaPlayer.OnInfoListener() {
        @Override
        public boolean onInfo(IMediaPlayer iMediaPlayer, int i, int i1) {
            switch (i) {
                case KSYMediaPlayer.MEDIA_INFO_BUFFERING_START:
                    LangHuaAppTLog.debug("开始缓冲数据");
                    break;
                case KSYMediaPlayer.MEDIA_INFO_BUFFERING_END:
                    LangHuaAppTLog.debug("数据缓冲完毕");
                    break;
                case KSYMediaPlayer.MEDIA_INFO_AUDIO_RENDERING_START:
                    LangHuaAppTLog.debug("开始播放音频");
                    break;
                case KSYMediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START:
                    LangHuaAppTLog.debug("开始缓冲数据");
                    break;
                case KSYMediaPlayer.MEDIA_INFO_SUGGEST_RELOAD:
                    // 播放SDK有做快速开播的优化，在流的音视频数据交织并不好时，可能只找到某一个流的信息
                    // 当播放器读到另一个流的数据时会发出此消息通知
                    // 请务必调用reload接口
                    if (videoView != null)
                        videoView.reload(videoInfoModel.getVideoUrl(), false);
                    break;
                case KSYMediaPlayer.MEDIA_INFO_RELOADED:
                    LangHuaAppTLog.debug("reload成功的消息通知");
                    break;
            }
            return false;
        }
    };

    private IMediaPlayer.OnMessageListener mOnMessageListener = new IMediaPlayer.OnMessageListener() {
        @Override
        public void onMessage(IMediaPlayer iMediaPlayer, Bundle bundle) {
            LangHuaAppTLog.info("IMediaPlayer.OnMessageListener");
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (videoView != null) {
            videoView.release();
            videoView = null;
        }
    }
}
