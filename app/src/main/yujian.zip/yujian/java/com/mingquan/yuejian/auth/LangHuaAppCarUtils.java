package com.mingquan.yuejian.auth;

import com.mingquan.yuejian.utils.LangHuaAppTLog;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by Administrator on 2018/10/19
 */
public class LangHuaAppCarUtils {
    private static final String TAG = "LangHuaAppCarUtils";

    public static String carToStr(InputStream inputStream) throws IOException {
        ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();
        // 数组长度
        byte[] buffer = new byte[1024];
        // 初始长度
        int len = 0;
        // 循环
        while ((len = inputStream.read(buffer)) != -1) {
            arrayOutputStream.write(buffer, 0, len);
//            return arrayOutputStream.toString();
        }
        LangHuaAppTLog.info(arrayOutputStream.toString());
        return arrayOutputStream.toString();
    }
}
