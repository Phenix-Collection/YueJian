package com.mingquan.yuejian.vchat;

import com.mingquan.yuejian.proto.model.LangHuaAppACGiftModel;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserPublicInfoModel;

public class LangHuaAppShowGiftMessageEvent {
    private LangHuaAppACGiftModel giftModel;
    private LangHuaAppACUserPublicInfoModel senderModel;
    private LangHuaAppACUserPublicInfoModel receiverModel;

    public LangHuaAppShowGiftMessageEvent(LangHuaAppACGiftModel gift, LangHuaAppACUserPublicInfoModel sender, LangHuaAppACUserPublicInfoModel receiver) {
        this.giftModel = gift;
        this.senderModel = sender;
        this.receiverModel = receiver;
    }

    public LangHuaAppACGiftModel getGiftModel() {
        return giftModel;
    }

    public void setGiftModel(LangHuaAppACGiftModel giftModel) {
        this.giftModel = giftModel;
    }

    public LangHuaAppACUserPublicInfoModel getSenderModel() {
        return senderModel;
    }

    public void setSenderModel(LangHuaAppACUserPublicInfoModel senderModel) {
        this.senderModel = senderModel;
    }

    public LangHuaAppACUserPublicInfoModel getReceiverModel() {
        return receiverModel;
    }

    public void setReceiverModel(LangHuaAppACUserPublicInfoModel receiverModel) {
        this.receiverModel = receiverModel;
    }
}