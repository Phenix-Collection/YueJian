package com.mingquan.yuejian.huawei.common;

/**
 * 不混淆类
 */
public interface LangHuaAppINoProguard {
}
