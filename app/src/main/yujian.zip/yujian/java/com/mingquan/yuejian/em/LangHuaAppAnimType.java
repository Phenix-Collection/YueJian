package com.mingquan.yuejian.em;

/**
 * Created by Jiantao on 2017/5/19.
 */

public enum LangHuaAppAnimType {
  Single,
  Recycle,
  TWICE,
}
