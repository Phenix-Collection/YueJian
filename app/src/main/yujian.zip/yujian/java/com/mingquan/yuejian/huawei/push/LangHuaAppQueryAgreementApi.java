package com.mingquan.yuejian.huawei.push;

import android.os.Handler;
import android.os.Looper;

import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.support.api.push.HuaweiPush;
import com.mingquan.yuejian.huawei.LangHuaAppHMSAgent;
import com.mingquan.yuejian.huawei.common.LangHuaAppApiClientMgr;
import com.mingquan.yuejian.huawei.common.LangHuaAppBaseApiAgent;
import com.mingquan.yuejian.huawei.common.LangHuaAppCallbackCodeRunnable;
import com.mingquan.yuejian.huawei.common.LangHuaAppHMSAgentLog;
import com.mingquan.yuejian.huawei.common.LangHuaAppStrUtils;
import com.mingquan.yuejian.huawei.common.LangHuaAppThreadUtil;
import com.mingquan.yuejian.huawei.push.handler.LangHuaAppQueryAgreementHandler;

/**
 * 获取push协议展示的接口。
 */
public class LangHuaAppQueryAgreementApi extends LangHuaAppBaseApiAgent {

    /**
     * 调用接口回调
     */
    private LangHuaAppQueryAgreementHandler handler;

    /**
     * HuaweiApiClient 连接结果回调
     *
     * @param rst    结果码
     * @param client HuaweiApiClient 实例
     */
    @Override
    public void onConnect(final int rst, final HuaweiApiClient client) {
        //需要在子线程中执行获取push协议展示的操作
        LangHuaAppThreadUtil.INST.excute(new Runnable() {
            @Override
            public void run() {
                if (client == null || !LangHuaAppApiClientMgr.INST.isConnect(client)) {
                    LangHuaAppHMSAgentLog.e("client not connted");
                    onQueryAgreementResult(rst);
                } else {
                    HuaweiPush.HuaweiPushApi.queryAgreement(client);
                    onQueryAgreementResult(LangHuaAppHMSAgent.AgentResultCode.HMSAGENT_SUCCESS);
                }
            }
        });
    }

    void onQueryAgreementResult(int rstCode) {
        LangHuaAppHMSAgentLog.i("queryAgreement:callback=" + LangHuaAppStrUtils.objDesc(handler) +" retCode=" + rstCode);
        if (handler != null) {
            new Handler(Looper.getMainLooper()).post(new LangHuaAppCallbackCodeRunnable(handler, rstCode));
            handler = null;
        }
    }

    /**
     * 请求push协议展示
     */
    public void queryAgreement(LangHuaAppQueryAgreementHandler handler) {
        LangHuaAppHMSAgentLog.i("queryAgreement:handler=" + LangHuaAppStrUtils.objDesc(handler));
        this.handler = handler;
        connect();
    }
}
