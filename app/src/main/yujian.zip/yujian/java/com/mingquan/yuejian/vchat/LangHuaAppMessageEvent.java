package com.mingquan.yuejian.vchat;

public class LangHuaAppMessageEvent {
        private String message;
        public  LangHuaAppMessageEvent(String message){
            this.message=message;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }