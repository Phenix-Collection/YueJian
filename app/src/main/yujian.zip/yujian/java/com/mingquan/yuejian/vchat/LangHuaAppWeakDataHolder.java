package com.mingquan.yuejian.vchat;

import com.mingquan.yuejian.proto.model.LangHuaAppACVideoInfoModel;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Intent传递大量数据出现TransactionTooLargeException异常的解决方案
 */

public class LangHuaAppWeakDataHolder {

    private static LangHuaAppWeakDataHolder instance;

    public static LangHuaAppWeakDataHolder getInstance() {
        if (instance == null) {
            synchronized (LangHuaAppWeakDataHolder.class) {
                if (instance == null) {
                    instance = new LangHuaAppWeakDataHolder();
                }
            }
        }
        return instance;
    }

    private Map<String, WeakReference<List<LangHuaAppACVideoInfoModel>>> map = new HashMap<>();

    /**
     * 数据存储
     *
     * @param object
     */
    public void saveData(List<LangHuaAppACVideoInfoModel> object) {
        map.put("VIDEO_INFO_LIST", new WeakReference<>(object));
    }

    /**
     * 获取数据
     *
     * @return
     */
    public List<LangHuaAppACVideoInfoModel> getData() {
        WeakReference<List<LangHuaAppACVideoInfoModel>> weakReference = map.get("VIDEO_INFO_LIST");
        return weakReference.get();
    }
}