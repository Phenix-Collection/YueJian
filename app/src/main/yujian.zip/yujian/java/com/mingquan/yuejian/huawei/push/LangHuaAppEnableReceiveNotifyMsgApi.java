package com.mingquan.yuejian.huawei.push;

import android.os.Handler;
import android.os.Looper;

import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.support.api.push.HuaweiPush;
import com.mingquan.yuejian.huawei.LangHuaAppHMSAgent;
import com.mingquan.yuejian.huawei.common.LangHuaAppApiClientMgr;
import com.mingquan.yuejian.huawei.common.LangHuaAppBaseApiAgent;
import com.mingquan.yuejian.huawei.common.LangHuaAppCallbackCodeRunnable;
import com.mingquan.yuejian.huawei.common.LangHuaAppHMSAgentLog;
import com.mingquan.yuejian.huawei.common.LangHuaAppStrUtils;
import com.mingquan.yuejian.huawei.common.LangHuaAppThreadUtil;
import com.mingquan.yuejian.huawei.push.handler.LangHuaAppEnableReceiveNotifyMsgHandler;

/**
 * 打开自呈现消息开关的接口。
 */
public class LangHuaAppEnableReceiveNotifyMsgApi extends LangHuaAppBaseApiAgent {

    /**
     * 是否打开开关
     */
    boolean enable;

    /**
     * 调用接口回调
     */
    private LangHuaAppEnableReceiveNotifyMsgHandler handler;

    /**
     * HuaweiApiClient 连接结果回调
     *
     * @param rst    结果码
     * @param client HuaweiApiClient 实例
     */
    @Override
    public void onConnect(final int rst, final HuaweiApiClient client) {
        //需要在子线程中执行开关的操作
        LangHuaAppThreadUtil.INST.excute(new Runnable() {
            @Override
            public void run() {
                if (client == null || !LangHuaAppApiClientMgr.INST.isConnect(client)) {
                    LangHuaAppHMSAgentLog.e("client not connted");
                    onEnableReceiveNotifyMsgResult(rst);
                } else {
                    // 开启/关闭自呈现消息
                    HuaweiPush.HuaweiPushApi.enableReceiveNotifyMsg(client, enable);
                    onEnableReceiveNotifyMsgResult(LangHuaAppHMSAgent.AgentResultCode.HMSAGENT_SUCCESS);
                }
            }
        });
    }

    void onEnableReceiveNotifyMsgResult(int rstCode) {
        LangHuaAppHMSAgentLog.i("enableReceiveNotifyMsg:callback=" + LangHuaAppStrUtils.objDesc(handler) +" retCode=" + rstCode);
        if (handler != null) {
            new Handler(Looper.getMainLooper()).post(new LangHuaAppCallbackCodeRunnable(handler, rstCode));
            handler = null;
        }
    }

    /**
     * 打开/关闭自呈现消息
     * @param enable 打开/关闭
     */
    public void enableReceiveNotifyMsg(boolean enable, LangHuaAppEnableReceiveNotifyMsgHandler handler) {
        LangHuaAppHMSAgentLog.i("enableReceiveNotifyMsg:enable=" + enable + " handler=" + LangHuaAppStrUtils.objDesc(handler));
        this.enable = enable;
        this.handler = handler;
        connect();
    }
}
