package com.mingquan.yuejian.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.adapter.holder.LangHuaAppRecyclerViewHolder;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserTagMetaDataModel;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserTaggingModel;
import com.mingquan.yuejian.utils.LangHuaAppTLog;
import com.mingquan.yuejian.vchat.LangHuaAppLabelGroup;
import com.mingquan.yuejian.widget.LangHuaAppAvatarView;

import java.util.ArrayList;

/**
 * Created by administrator on 2018/9/29.
 * <p>
 * 用户标签记录 adapter
 */

public class LangHuaAppTagRecordAdapter extends LangHuaAppBaseRecyclerMutilAdapter<LangHuaAppACUserTaggingModel> {


    public LangHuaAppTagRecordAdapter(Context ctx) {
        super(ctx);
    }

    @Override
    public LangHuaAppRecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new LangHuaAppRecyclerViewHolder(
                context,
                LayoutInflater.from(context).inflate(R.layout.lang_hua_app_item_tagging_record, null, false)
        );
    }

    @Override
    public void onBindViewHolder(final LangHuaAppRecyclerViewHolder holder, final int position) {
        LangHuaAppACUserTaggingModel model = list.get(position);

        if (model == null) {
            LangHuaAppTLog.error("user tagging model == null");
            return;
        }
        ((LangHuaAppAvatarView)holder.getImageView(R.id.avatar)).setAvatarUrl(model.getAvatar());
        holder.getTextView(R.id.tv_name).setText(model.getNickname());
        LangHuaAppACUserTagMetaDataModel tagMetaDataModel = LangHuaAppAppContext.getInstance().getUserTagMetaByTagId(model.getTagId());
        ArrayList<LangHuaAppACUserTagMetaDataModel> tagList = new ArrayList<>();
        tagList.add(tagMetaDataModel);
        ((LangHuaAppLabelGroup)holder.getView(R.id.label_container)).setLabels(tagList);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
