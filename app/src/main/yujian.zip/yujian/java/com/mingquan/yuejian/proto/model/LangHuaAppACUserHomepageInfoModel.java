/*
 * Copyright (C) 2017 QR Co. All rights reserved.
 *
 * Created by tool, DO NOT EDIT!!!
 */

package com.mingquan.yuejian.proto.model;

import com.mingquan.yuejian.utils.LangHuaAppRavenUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * LangHuaAppACUserHomepageInfoModel
 */
public class LangHuaAppACUserHomepageInfoModel implements Serializable {
    private LangHuaAppACUserPublicInfoModel user; // 用户基本信息
    private ArrayList<LangHuaAppACUserPublicInfoModel> top3; // 贡献榜前三名
    private LangHuaAppACRelationModel relation; // 和目标用户之间的关系

    /**
     * ACUserHomepageInfoModel的构造函数
     * @param json json数据源
     */
    public LangHuaAppACUserHomepageInfoModel(JSONObject json) {
        // 设置默认值
        this.user = new LangHuaAppACUserPublicInfoModel(null); // 用户基本信息
        this.top3 = new ArrayList<LangHuaAppACUserPublicInfoModel>(); // 贡献榜前三名
        this.relation = new LangHuaAppACRelationModel(null); // 和目标用户之间的关系

        // 解析JSON数据
        String current_field_name = "";
        try {
            if (json != null) {
                // 用户基本信息
                current_field_name = "user";
                if (json.has("user")) {
                    this.user = new LangHuaAppACUserPublicInfoModel(json.getJSONObject("user"));
        
                }
    
                // 贡献榜前三名
                current_field_name = "top3";
                if (json.has("top3")) {
                    JSONArray top3Json = json.getJSONArray("top3");
                    for (int i = 0; i < top3Json.length(); i++) {
                        LangHuaAppACUserPublicInfoModel model = new LangHuaAppACUserPublicInfoModel(top3Json.getJSONObject(i));
                        this.top3.add(model);
                    }
        
                }
    
                // 和目标用户之间的关系
                current_field_name = "relation";
                if (json.has("relation")) {
                    this.relation = new LangHuaAppACRelationModel(json.getJSONObject("relation"));
        
                }
    
            }
        } catch (Exception e) {
          HashMap<String, Object> extension = new HashMap<>();
            extension.put("model", "LangHuaAppACUserHomepageInfoModel");
            extension.put("field", current_field_name);
            LangHuaAppRavenUtils.logException("解析JSON数据失败", e, extension);
        }
    }
    
    /**
     * 用户基本信息
     */
    public LangHuaAppACUserPublicInfoModel getUser() { return user; }
    public void setUser(LangHuaAppACUserPublicInfoModel value) { this.user = value; }
    
    /**
     * 贡献榜前三名
     */
    public ArrayList<LangHuaAppACUserPublicInfoModel> getTop3() { return top3; }
    public void setTop3(ArrayList<LangHuaAppACUserPublicInfoModel> value) { this.top3 = value; }
    
    /**
     * 和目标用户之间的关系
     */
    public LangHuaAppACRelationModel getRelation() { return relation; }
    public void setRelation(LangHuaAppACRelationModel value) { this.relation = value; }
    

    @Override
    public String toString() {
        return "LangHuaAppACUserHomepageInfoModel{" +
                "user=" + user +
                ", top3=" + top3 +
                ", relation=" + relation +
                '}';
    }

    
}