package com.mingquan.yuejian.huawei.common;

/**
 * 回调线程
 */
public class LangHuaAppCallbackCodeRunnable implements Runnable {

    private LangHuaAppICallbackCode handlerInner;
    private int rtnCodeInner;

    public LangHuaAppCallbackCodeRunnable(LangHuaAppICallbackCode handler, int rtnCode) {
        handlerInner = handler;
        rtnCodeInner = rtnCode;
    }

    @Override
    public void run() {
        if (handlerInner != null) {
            handlerInner.onResult(rtnCodeInner);
        }
    }
}