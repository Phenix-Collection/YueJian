package com.mingquan.yuejian.utils;

import com.mingquan.yuejian.bean.LangHuaAppChatBean;
import com.mingquan.yuejian.bean.LangHuaAppSendGiftBean;
import com.mingquan.yuejian.interf.LangHuaAppIChatServer;

/**
 * Created by administrato on 2017/5/3.
 */

public class LangHuaAppSocketHandlerUtils implements LangHuaAppIChatServer {

  @Override
  public void onConnect(boolean res) {

  }

  @Override
  public void onShowSendGift(
          LangHuaAppSendGiftBean contentJson, LangHuaAppChatBean chatBean, int index, String broadCastVotes) {

  }

  @Override
  public void onError() {}

}
