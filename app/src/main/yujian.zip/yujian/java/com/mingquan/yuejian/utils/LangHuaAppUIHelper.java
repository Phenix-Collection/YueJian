package com.mingquan.yuejian.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.widget.Toast;

import com.mingquan.yuejian.LangHuaAppAppConfig;
import com.mingquan.yuejian.LangHuaAppAppContext;
import com.mingquan.yuejian.R;
import com.mingquan.yuejian.agora.LangHuaAppFUDualInputToTextureExampleActivity;
import com.mingquan.yuejian.auth.LangHuaAppAuthActivity;
import com.mingquan.yuejian.auth.LangHuaAppEditAuthInfoActivity;
import com.mingquan.yuejian.bean.LangHuaAppSimpleBackPage;
import com.mingquan.yuejian.em.LangHuaAppChangInfo;
import com.mingquan.yuejian.fragment.LangHuaAppDiamondDialogFragment;
import com.mingquan.yuejian.interf.LangHuaAppINomalDialog;
import com.mingquan.yuejian.proto.LangHuaAppApiProtoHelper;
import com.mingquan.yuejian.proto.model.LangHuaAppACUserPublicInfoModel;
import com.mingquan.yuejian.proto.model.LangHuaAppACVideoInfoModel;
import com.mingquan.yuejian.ui.LangHuaAppEditInfoActivity;
import com.mingquan.yuejian.ui.LangHuaAppLiveLoginSelectActivity;
import com.mingquan.yuejian.ui.LangHuaAppMainActivity;
import com.mingquan.yuejian.ui.LangHuaAppMyDiamondListActivity;
import com.mingquan.yuejian.ui.LangHuaAppMyInfoDetailActivity;
import com.mingquan.yuejian.ui.LangHuaAppPhoneLoginActivity;
import com.mingquan.yuejian.ui.LangHuaAppSelectAvatarActivity;
import com.mingquan.yuejian.ui.LangHuaAppSimpleBackActivity;
import com.mingquan.yuejian.ui.LangHuaAppWebViewActivity;
import com.mingquan.yuejian.ui.dialog.LangHuaAppDialogHelper;
import com.mingquan.yuejian.vchat.LangHuaAppSetVideoPriceActivity;
import com.mingquan.yuejian.vchat.LangHuaAppSettingBeautyActivity2;
import com.mingquan.yuejian.vchat.LangHuaAppUploadVideoActivity;
import com.mingquan.yuejian.vchat.LangHuaAppVChatShortVideoPlayActivity;
import com.mingquan.yuejian.vchat.LangHuaAppVChatShortVideoPlayerActivity;
import com.mingquan.yuejian.vchat.LangHuaAppWeakDataHolder;

import java.util.List;

/**
 * 界面帮助类
 */

public class LangHuaAppUIHelper {
    /**
     * 手机登录
     *
     * @param context
     */

    public static void showMobilLogin(Context context) {
        Intent intent = new Intent(context, LangHuaAppPhoneLoginActivity.class);
        context.startActivity(intent);
    }

    /**
     * 登陆选择
     *
     * @param context
     */
    public static void showLoginSelectActivity(Context context) {
        if (context == null)
            return;
        Intent intent = new Intent(context, LangHuaAppLiveLoginSelectActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
    }

    /**
     * 首页
     *
     * @param context
     */
    public static void showMainActivity(Context context) {
        Intent intent = new Intent(context, LangHuaAppMainActivity.class);
        //        Intent intent = new Intent(context, IndexActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
    }

    /**
     * 我的详细资料
     *
     * @param context
     */
    public static void showMyInfoDetailActivity(Context context) {
        Intent intent = new Intent(context, LangHuaAppMyInfoDetailActivity.class);
        context.startActivity(intent);
    }

    /**
     * 编辑资料
     *
     * @param context
     */
    public static void showEditInfoActivity(LangHuaAppMyInfoDetailActivity context, String action,
                                            String prompt, String defaultStr, LangHuaAppChangInfo changInfo) {
        Intent intent = new Intent(context, LangHuaAppEditInfoActivity.class);
        intent.putExtra(LangHuaAppEditInfoActivity.EDITACTION, action);
        intent.putExtra(LangHuaAppEditInfoActivity.EDITDEFAULT, defaultStr);
        intent.putExtra(LangHuaAppEditInfoActivity.EDITPROMP, prompt);
        intent.putExtra(LangHuaAppEditInfoActivity.EDITKEY, changInfo.getAction());
        context.startActivity(intent);
//    context.overridePendingTransition(R.anim.lang_hua_app_activity_open_start, 0);
    }

    public static void showSelectAvatar(LangHuaAppMyInfoDetailActivity context, String avatar) {
        Intent intent = new Intent(context, LangHuaAppSelectAvatarActivity.class);
        intent.putExtra("uhead", avatar);
        context.startActivity(intent);
//    context.overridePendingTransition(R.anim.lang_hua_app_activity_open_start, 0);
    }

    /**
     * 我的钻石
     *
     * @return
     */
    public static void showMyDiamonds(Context context, Bundle bundle) {
        Intent intent = new Intent(context, LangHuaAppMyDiamondListActivity.class);
        intent.putExtra("USERINFO", bundle);
        context.startActivity(intent);
    }

    /**
     * 我的钻石DialogFragment
     *
     * @return
     */
    public static void showMyDiamondsDialogFragment(FragmentManager fragmentManager, Bundle bundle) {
        LangHuaAppDiamondDialogFragment diamondDialogFragment = new LangHuaAppDiamondDialogFragment();
        diamondDialogFragment.setStyle(DialogFragment.STYLE_NO_TITLE, R.style.CustomDialog);
        diamondDialogFragment.setArguments(bundle);
        diamondDialogFragment.show(fragmentManager, "LangHuaAppDiamondDialogFragment");
    }

    /**
     * 视频聊天页面
     *
     * @param context
     * @param user
     * @param liveId  连麦的房间号
     */
    public static void showVideoChatActivity(
            final Context context,
            LangHuaAppACUserPublicInfoModel user,
            String liveId) {
        LangHuaAppTLog.debug("LangHuaAppUIHelper 打开视频聊天");

        boolean canVideoChat = LangHuaAppAppContext.getInstance().getPrivateInfoModel().getCanVideoChat();
        if (!canVideoChat) {
            LangHuaAppTLog.error("can video chat == false");
            return;
        }

        if (LangHuaAppAppContext.getInstance().getLoginUid().equals(user.getUid())) {
            Toast.makeText(context, "不能跟自己连麦", Toast.LENGTH_SHORT).show();
            return;
        }

        if (LangHuaAppStringUtil.isEmpty(liveId) && user.getUid().equals("120001")) { // 不能给客服打电话
            Toast.makeText(context, "不能跟客服连麦", Toast.LENGTH_SHORT).show();
            return;
        }

        // 自己不是主播，对方是主播，检查钻石是否足够
        if (!LangHuaAppAppContext.getInstance().getAcPublicUser().getIsBroadcaster()
                && user.getIsBroadcaster()
                && LangHuaAppAppContext.getInstance().getPrivateInfoModel().getDiamond() < user.getPrice()) {
            LangHuaAppDialogHelp.showDialog(context, "钻石不足，是否立即充值", new LangHuaAppINomalDialog() {
                @Override
                public void cancelDialog(View v, Dialog d) {
                    d.dismiss();
                }

                @Override
                public void determineDialog(View v, Dialog d) {
                    LangHuaAppDialogHelper.showRechargeDialogFragment(((FragmentActivity) context).getSupportFragmentManager());
                    d.dismiss();
                }
            });
            return;
        }

        if (LangHuaAppStringUtil.isEmpty(liveId)) {
            inviteVipChat(context, user);
        } else {
            fetchAgoraToken(context, user, false, liveId);
        }
    }

    /**
     * 发送邀请连麦
     */
    private static void inviteVipChat(
            final Context context,
            final LangHuaAppACUserPublicInfoModel user) {
        LangHuaAppApiProtoHelper.sendACInviteVipChatReq(
                null,
                LangHuaAppAppContext.getInstance().getLoginUid(),
                LangHuaAppAppContext.getInstance().getToken(),
                user.getUid(),
                !LangHuaAppAppConfig.DEBUG,
                new LangHuaAppApiProtoHelper.ACInviteVipChatReqCallback() {
                    @Override
                    public void onError(int errCode, String errMessage) {
                        LangHuaAppTLog.error(errMessage);
                        Toast.makeText(context, errMessage, Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onResponse(String liveid) {
                        fetchAgoraToken(context, user, true, liveid);
                    }
                }
        );
    }

    /**
     * 获取声网token
     *
     * @param context
     * @param user
     * @param isSender
     * @param liveId
     */
    private static void fetchAgoraToken(
            final Context context,
            final LangHuaAppACUserPublicInfoModel user,
            final boolean isSender,
            final String liveId) {
        LangHuaAppApiProtoHelper.sendACFetchAgoraTokenReq(
                null,
                LangHuaAppAppContext.getInstance().getLoginUid(),
                LangHuaAppAppContext.getInstance().getToken(),
                liveId,
                new LangHuaAppApiProtoHelper.ACFetchAgoraTokenReqCallback() {
                    @Override
                    public void onError(int errCode, String errMessage) {
                        LangHuaAppTLog.error(errMessage);
                    }

                    @Override
                    public void onResponse(String token) {
                        Intent intent = new Intent(context, LangHuaAppFUDualInputToTextureExampleActivity.class);
                        intent.putExtra("user_public_info", user);
                        intent.putExtra("agora_token", token);
                        intent.putExtra("is_sender", isSender);
                        intent.putExtra("live_id", liveId);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        context.startActivity(intent);
                    }
                });
    }

    public static void showShortVideoActivity(Context context, LangHuaAppACVideoInfoModel videoInfoModel) {
        LangHuaAppTLog.debug("LangHuaAppUIHelper 打开短视频播放页面");
        Intent intent = new Intent(context, LangHuaAppVChatShortVideoPlayActivity.class);
        intent.putExtra("videoInfo", videoInfoModel);
        context.startActivity(intent);
    }

    public static void showShortVideoPlayerActivity(Context context, List<LangHuaAppACVideoInfoModel> videoInfoModels, int position) {
        LangHuaAppTLog.debug("showShortVideoPlayerActivity");
        LangHuaAppWeakDataHolder.getInstance().saveData(videoInfoModels);
        Intent intent = new Intent(context, LangHuaAppVChatShortVideoPlayerActivity.class);
        intent.putExtra("POSITION", position);
        context.startActivity(intent);
    }

    //私信详情
    public static void showPrivateChatdetailFragment(Context context, LangHuaAppACUserPublicInfoModel user) {
        Intent intent = new Intent(context, LangHuaAppSimpleBackActivity.class);
        intent.putExtra("user", user);
        intent.putExtra(LangHuaAppSimpleBackActivity.BUNDLE_KEY_PAGE, LangHuaAppSimpleBackPage.USER_PRIVATECORE_DETAIL.getValue());
        context.startActivity(intent);
    }

    //搜索
    public static void showSearch(Context context) {
        Intent intent = new Intent(context, LangHuaAppSimpleBackActivity.class);
        intent.putExtra(LangHuaAppSimpleBackActivity.BUNDLE_KEY_PAGE, LangHuaAppSimpleBackPage.INDEX_SECREEN.getValue());
        context.startActivity(intent);
    }

    //打开网页
    public static void showWebView(Context context, String url, String title) {
        Intent intent = new Intent(context, LangHuaAppWebViewActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("URL", url);
        bundle.putString("TITLE", title);
        intent.putExtra("URL_INFO", bundle);
        context.startActivity(intent);
    }

    /**
     * 我的钻石列表页面
     *
     * @param context
     */
    public static void showMyDiamondListActivity(Context context) {
        Intent intent = new Intent(context, LangHuaAppMyDiamondListActivity.class);
        context.startActivity(intent);
    }

    /**
     * 认证
     *
     * @param context
     */
    public static void showAuthActivity(Context context) {
        Intent intent = new Intent(context, LangHuaAppAuthActivity.class);
        context.startActivity(intent);
    }

    /**
     * 编辑认证资料页面
     *
     * @param context
     */
    public static void showEditAuthinfoActivity(Context context) {
        Intent intent = new Intent(context, LangHuaAppEditAuthInfoActivity.class);
        context.startActivity(intent);
    }

    /**
     * 上传头像页面
     *
     * @param context
     */
    public static void showUploadVideoActivity(Context context) {
        Intent intent = new Intent(context, LangHuaAppUploadVideoActivity.class);
        context.startActivity(intent);
    }

    /**
     * 设置短视频价格页面
     *
     * @param context
     */
    public static void showSetVideoPriceActivity(Activity context, int videoId) {
        Intent intent = new Intent(context, LangHuaAppSetVideoPriceActivity.class);
        intent.putExtra("VIDEO_ID", videoId);
        context.startActivityForResult(intent, 100);
    }

    /**
     * 设置美颜页面
     *
     * @param context
     */
    public static void showSettingBeautyActivity(Context context) {
        Intent intent = new Intent(context, LangHuaAppSettingBeautyActivity2.class);
        context.startActivity(intent);
    }
}
