package com.mingquan.yuejian.huawei.push.handler;

import com.mingquan.yuejian.huawei.common.LangHuaAppICallbackCode;

/**
 * getPushState 回调
 */
public interface LangHuaAppGetPushStateHandler extends LangHuaAppICallbackCode {
}
