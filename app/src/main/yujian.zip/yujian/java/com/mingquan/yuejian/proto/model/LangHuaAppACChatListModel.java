/*
 * Copyright (C) 2017 QR Co. All rights reserved.
 *
 * Created by tool, DO NOT EDIT!!!
 */

package com.mingquan.yuejian.proto.model;

import com.mingquan.yuejian.utils.LangHuaAppRavenUtils;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

/**
 * LangHuaAppACChatListModel
 */
public class LangHuaAppACChatListModel implements Serializable {
    private LangHuaAppACUserPublicInfoModel user; // 用户基本信息
    private LangHuaAppACChatMessageModel lastMessage; // 最近的聊天记录

    /**
     * ACChatListModel的构造函数
     * @param json json数据源
     */
    public LangHuaAppACChatListModel(JSONObject json) {
        // 设置默认值
        this.user = new LangHuaAppACUserPublicInfoModel(null); // 用户基本信息
        this.lastMessage = new LangHuaAppACChatMessageModel(null); // 最近的聊天记录

        // 解析JSON数据
        String current_field_name = "";
        try {
            if (json != null) {
                // 用户基本信息
                current_field_name = "user";
                if (json.has("user")) {
                    this.user = new LangHuaAppACUserPublicInfoModel(json.getJSONObject("user"));
        
                }
    
                // 最近的聊天记录
                current_field_name = "last_message";
                if (json.has("last_message")) {
                    this.lastMessage = new LangHuaAppACChatMessageModel(json.getJSONObject("last_message"));
        
                }
    
            }
        } catch (Exception e) {
          HashMap<String, Object> extension = new HashMap<>();
            extension.put("model", "LangHuaAppACChatListModel");
            extension.put("field", current_field_name);
            LangHuaAppRavenUtils.logException("解析JSON数据失败", e, extension);
        }
    }
    
    /**
     * 用户基本信息
     */
    public LangHuaAppACUserPublicInfoModel getUser() { return user; }
    public void setUser(LangHuaAppACUserPublicInfoModel value) { this.user = value; }
    
    /**
     * 最近的聊天记录
     */
    public LangHuaAppACChatMessageModel getLastMessage() { return lastMessage; }
    public void setLastMessage(LangHuaAppACChatMessageModel value) { this.lastMessage = value; }
    

    @Override
    public String toString() {
        return "LangHuaAppACChatListModel{" +
                "user=" + user +
                ", lastMessage=" + lastMessage +
                '}';
    }

    
}