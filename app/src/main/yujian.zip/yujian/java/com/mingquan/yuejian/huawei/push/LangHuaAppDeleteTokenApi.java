package com.mingquan.yuejian.huawei.push;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.support.api.push.HuaweiPush;
import com.mingquan.yuejian.huawei.LangHuaAppHMSAgent;
import com.mingquan.yuejian.huawei.common.LangHuaAppApiClientMgr;
import com.mingquan.yuejian.huawei.common.LangHuaAppBaseApiAgent;
import com.mingquan.yuejian.huawei.common.LangHuaAppCallbackCodeRunnable;
import com.mingquan.yuejian.huawei.common.LangHuaAppHMSAgentLog;
import com.mingquan.yuejian.huawei.common.LangHuaAppStrUtils;
import com.mingquan.yuejian.huawei.common.LangHuaAppThreadUtil;
import com.mingquan.yuejian.huawei.push.handler.LangHuaAppDeleteTokenHandler;

/**
 * 删除pushtoken的接口。
 */
public class LangHuaAppDeleteTokenApi extends LangHuaAppBaseApiAgent {

    /**
     * 待删除的push token
     */
    private String token;

    /**
     * 调用接口回调
     */
    private LangHuaAppDeleteTokenHandler handler;

    /**
     * HuaweiApiClient 连接结果回调
     *
     * @param rst    结果码
     * @param client HuaweiApiClient 实例
     */
    @Override
    public void onConnect(final int rst, final HuaweiApiClient client) {
        //需要在子线程中执行删除TOKEN操作
        LangHuaAppThreadUtil.INST.excute(new Runnable() {
            @Override
            public void run() {
                //调用删除TOKEN需要传入通过getToken接口获取到TOKEN，并且需要对TOKEN进行非空判断
                if (!TextUtils.isEmpty(token)){
                    if (client == null || !LangHuaAppApiClientMgr.INST.isConnect(client)) {
                        LangHuaAppHMSAgentLog.e("client not connted");
                        onDeleteTokenResult(rst);
                    } else {
                        try {
                            HuaweiPush.HuaweiPushApi.deleteToken(client, token);
                            onDeleteTokenResult(LangHuaAppHMSAgent.AgentResultCode.HMSAGENT_SUCCESS);
                        } catch (Exception e) {
                            LangHuaAppHMSAgentLog.e("删除TOKEN失败:" + e.getMessage());
                            onDeleteTokenResult(LangHuaAppHMSAgent.AgentResultCode.CALL_EXCEPTION);
                        }
                    }
                } else {
                    LangHuaAppHMSAgentLog.e("删除TOKEN失败: 要删除的token为空");
                    onDeleteTokenResult(LangHuaAppHMSAgent.AgentResultCode.EMPTY_PARAM);
                }
            }
        });
    }

    void onDeleteTokenResult(int rstCode) {
        LangHuaAppHMSAgentLog.i("deleteToken:callback=" + LangHuaAppStrUtils.objDesc(handler) +" retCode=" + rstCode);
        if (handler != null) {
            new Handler(Looper.getMainLooper()).post(new LangHuaAppCallbackCodeRunnable(handler, rstCode));
            handler = null;
        }
    }

    /**
     * 删除指定的pushtoken
     * 该接口只在EMUI5.1以及更高版本的华为手机上调用该接口后才不会收到PUSH消息。
     * @param token 要删除的token
     */
    public void deleteToken(String token, LangHuaAppDeleteTokenHandler handler) {
        LangHuaAppHMSAgentLog.i("deleteToken:token:" + LangHuaAppStrUtils.objDesc(token) + " handler=" + LangHuaAppStrUtils.objDesc(handler));
        this.token = token;
        this.handler = handler;
        connect();
    }
}